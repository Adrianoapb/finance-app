/**
 * FinanceApp — Agenda Module
 * Lançamentos futuros, parcelas de cartão e notificações de vencimento
 */

// ─────────────────────────────────────────────
//  STATE
// ─────────────────────────────────────────────
let agendaFilter   = 'all';   // all | pending | overdue | paid
let agendaTab      = 'scheduled'; // scheduled | installments
let editScheduledId = null;

const RECURRENCE_LABELS = {
  none:    'Não repete',
  daily:   'Diário',
  weekly:  'Semanal',
  monthly: 'Mensal',
  yearly:  'Anual'
};

// ─────────────────────────────────────────────
//  RENDER AGENDA PAGE
// ─────────────────────────────────────────────
function renderAgenda() {
  renderAgendaSummary();
  if (agendaTab === 'scheduled') {
    renderScheduledList();
  } else {
    renderInstallmentsList();
  }
}

function renderAgendaSummary() {
  const all      = DB.scheduled.getAll();
  const pending  = all.filter(s => s.status === 'pending');
  const overdue  = DB.scheduled.getOverdue();
  const days     = DB.settings.get().notifyDaysBefore ?? 3;
  const dueSoon  = DB.scheduled.getDueSoon(days);

  const totalPending  = pending.reduce((s, x) => s + (x.amount || 0), 0);
  const totalOverdue  = overdue.reduce((s, x) => s + (x.amount || 0), 0);

  const el = document.getElementById('agendaSummary');
  if (!el) return;
  el.innerHTML = `
    <div class="agenda-sum-card pending" onclick="setAgendaFilter('pending')">
      <i class="fas fa-clock"></i>
      <div>
        <span>A Vencer</span>
        <strong>${pending.length}</strong>
        <small>${formatCurrency(totalPending)}</small>
      </div>
    </div>
    <div class="agenda-sum-card overdue" onclick="setAgendaFilter('overdue')">
      <i class="fas fa-exclamation-circle"></i>
      <div>
        <span>Vencidos</span>
        <strong>${overdue.length}</strong>
        <small>${formatCurrency(totalOverdue)}</small>
      </div>
    </div>
    <div class="agenda-sum-card soon" onclick="setAgendaFilter('soon')">
      <i class="fas fa-bell"></i>
      <div>
        <span>Próx. ${days}d</span>
        <strong>${dueSoon.length}</strong>
        <small>${dueSoon.length > 0 ? 'atenção!' : 'ok'}</small>
      </div>
    </div>`;
}

// ─────────────────────────────────────────────
//  SCHEDULED LIST
// ─────────────────────────────────────────────
function renderScheduledList() {
  const container = document.getElementById('agendaList');
  if (!container) return;

  let items = DB.scheduled.getAll()
    .filter(s => !s.installmentGroupId); // parcelas ficam na aba de installments

  const days = DB.settings.get().notifyDaysBefore ?? 3;
  const today = new Date().toISOString().slice(0, 10);
  const limitDay = new Date(); limitDay.setDate(limitDay.getDate() + days);
  const limitStr = limitDay.toISOString().slice(0, 10);

  if (agendaFilter === 'pending')  items = items.filter(s => s.status === 'pending');
  if (agendaFilter === 'overdue')  items = items.filter(s => s.status === 'pending' && s.dueDate < today);
  if (agendaFilter === 'paid')     items = items.filter(s => s.status === 'paid');
  if (agendaFilter === 'soon')     items = items.filter(s => s.status === 'pending' && s.dueDate >= today && s.dueDate <= limitStr);

  // Ordenar por data de vencimento
  items.sort((a, b) => (a.dueDate || '').localeCompare(b.dueDate || ''));

  if (!items.length) {
    container.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-calendar-check"></i>
        <p>Nenhum lançamento encontrado</p>
        <button onclick="openScheduledModal()">Criar Lançamento</button>
      </div>`;
    return;
  }

  container.innerHTML = items.map(s => buildScheduledCard(s, today, limitStr)).join('');
}

function buildScheduledCard(s, today, limitStr) {
  const cat     = DB.categories.getById(s.categoryId);
  const icon    = cat ? cat.icon : (s.type === 'income' ? '💰' : '📦');
  const color   = cat ? cat.color : (s.type === 'income' ? '#10b981' : '#ef4444');
  const catName = cat ? cat.name : 'Sem categoria';
  const acc     = DB.accounts.getById(s.accountId);
  const accName = acc ? acc.name : '';
  const rec     = RECURRENCE_LABELS[s.recurrence || 'none'];

  const isOverdue = s.status === 'pending' && s.dueDate < today;
  const isSoon    = s.status === 'pending' && s.dueDate >= today && s.dueDate <= limitStr;
  const isPaid    = s.status === 'paid';
  const isCancelled = s.status === 'cancelled';

  let statusBadge = '';
  if (isPaid)      statusBadge = '<span class="sched-badge paid">✓ Pago</span>';
  else if (isCancelled) statusBadge = '<span class="sched-badge cancelled">✗ Cancelado</span>';
  else if (isOverdue)   statusBadge = '<span class="sched-badge overdue">Vencido</span>';
  else if (isSoon)      statusBadge = '<span class="sched-badge soon">Vence em breve</span>';
  else                  statusBadge = '<span class="sched-badge pending">Pendente</span>';

  const dueDateFmt = s.dueDate
    ? new Date(s.dueDate + 'T12:00:00').toLocaleDateString('pt-BR', { day:'2-digit', month:'short', year:'numeric' })
    : '—';

  const typeColor = s.type === 'income' ? 'var(--accent-green)' : 'var(--accent-red)';
  const sign      = s.type === 'income' ? '+' : '-';

  return `
  <div class="sched-card ${isOverdue ? 'is-overdue' : ''} ${isSoon && !isOverdue ? 'is-soon' : ''} ${isPaid ? 'is-paid' : ''}">
    <div class="sched-card-top">
      <div class="sched-icon" style="background:${color}22">${icon}</div>
      <div class="sched-info">
        <div class="sched-desc">${escHtml(s.description || 'Sem descrição')}</div>
        <div class="sched-meta">
          ${catName}${accName ? ' · ' + escHtml(accName) : ''}
          ${s.recurrence && s.recurrence !== 'none' ? ' · <i class="fas fa-redo" style="font-size:10px"></i> ' + rec : ''}
        </div>
      </div>
      <div class="sched-right">
        <div class="sched-amount" style="color:${typeColor}">${sign} ${formatCurrency(s.amount)}</div>
        <div class="sched-due">📅 ${dueDateFmt}</div>
        ${statusBadge}
      </div>
    </div>
    ${s.status === 'pending' ? `
    <div class="sched-actions">
      <button class="sched-btn pay-btn" onclick="markScheduledPaid('${s.id}')">
        <i class="fas fa-check"></i> Marcar como Pago
      </button>
      <button class="sched-btn edit-btn" onclick="openEditScheduled('${s.id}')">
        <i class="fas fa-pen"></i>
      </button>
      <button class="sched-btn del-btn" onclick="deleteScheduledConfirm('${s.id}')">
        <i class="fas fa-trash"></i>
      </button>
    </div>` : `
    <div class="sched-actions">
      <button class="sched-btn del-btn" onclick="deleteScheduledConfirm('${s.id}')">
        <i class="fas fa-trash"></i> Excluir
      </button>
    </div>`}
  </div>`;
}

// ─────────────────────────────────────────────
//  INSTALLMENTS LIST
// ─────────────────────────────────────────────
function renderInstallmentsList() {
  const container = document.getElementById('agendaList');
  if (!container) return;

  const groups = DB.installments.getAll();

  if (!groups.length) {
    container.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-credit-card"></i>
        <p>Nenhuma compra parcelada</p>
        <button onclick="openInstallmentModal()">Lançar Parcelado</button>
      </div>`;
    return;
  }

  container.innerHTML = groups.map(g => {
    const cat     = DB.categories.getById(g.categoryId);
    const icon    = cat ? cat.icon : '💳';
    const color   = cat ? cat.color : '#8b5cf6';
    const catName = cat ? cat.name : 'Sem categoria';
    const acc     = DB.accounts.getById(g.accountId);
    const accName = acc ? acc.name : '';

    // Buscar parcelas deste grupo
    const parcelas = DB.scheduled.getAll().filter(s => s.installmentGroupId === g.id);
    const paid     = parcelas.filter(s => s.status === 'paid').length;
    const total    = g.installmentCount || parcelas.length;
    const pct      = total > 0 ? Math.round((paid / total) * 100) : 0;
    const remaining = parcelas.filter(s => s.status === 'pending')
      .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
    const nextDue  = remaining[0]?.dueDate;
    const nextFmt  = nextDue
      ? new Date(nextDue + 'T12:00:00').toLocaleDateString('pt-BR', { day:'2-digit', month:'short' })
      : '—';
    const amtEach  = +(g.totalAmount / g.installmentCount).toFixed(2);

    const today = new Date().toISOString().slice(0, 10);
    const days  = DB.settings.get().notifyDaysBefore ?? 3;
    const lim   = new Date(); lim.setDate(lim.getDate() + days);
    const limStr = lim.toISOString().slice(0, 10);
    const isOverdue = remaining[0] && remaining[0].dueDate < today;
    const isSoon    = remaining[0] && remaining[0].dueDate >= today && remaining[0].dueDate <= limStr;

    return `
    <div class="installment-card ${isOverdue ? 'is-overdue' : ''} ${isSoon && !isOverdue ? 'is-soon' : ''}">
      <div class="inst-header">
        <div class="sched-icon" style="background:${color}22">${icon}</div>
        <div class="sched-info">
          <div class="sched-desc">${escHtml(g.description)}</div>
          <div class="sched-meta">${catName}${accName ? ' · ' + escHtml(accName) : ''}</div>
        </div>
        <div class="sched-right">
          <div class="sched-amount" style="color:var(--accent-purple)">${formatCurrency(g.totalAmount)}</div>
          <div class="inst-parcela">${formatCurrency(amtEach)}/parc.</div>
        </div>
      </div>

      <div class="inst-progress-row">
        <span>${paid}/${total} parcelas pagas</span>
        ${nextDue ? `<span class="inst-next ${isOverdue ? 'overdue-txt' : isSoon ? 'soon-txt' : ''}">
          ${isOverdue ? '⚠️' : '📅'} Próx: ${nextFmt}
        </span>` : '<span style="color:var(--accent-green)">✅ Quitado</span>'}
      </div>
      <div class="progress-bar">
        <div class="progress-fill" style="width:${pct}%; background:${pct===100?'#10b981':isOverdue?'#ef4444':isSoon?'#f59e0b':'#8b5cf6'}"></div>
      </div>

      <div class="sched-actions" style="margin-top:8px">
        <button class="sched-btn edit-btn" onclick="showInstallmentParcelas('${g.id}')">
          <i class="fas fa-list"></i> Ver Parcelas
        </button>
        <button class="sched-btn del-btn" onclick="deleteInstallmentConfirm('${g.id}')">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>`;
  }).join('');
}

// ─────────────────────────────────────────────
//  FILTER & TABS
// ─────────────────────────────────────────────
function setAgendaFilter(filter) {
  agendaFilter = filter;
  document.querySelectorAll('.agenda-filter-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.filter === filter));
  renderScheduledList();
}

function switchAgendaTab(tab) {
  agendaTab = tab;
  document.querySelectorAll('.agenda-tab-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.tab === tab));
  document.getElementById('agendaAddBtn').onclick =
    tab === 'scheduled' ? openScheduledModal : openInstallmentModal;
  document.getElementById('agendaAddBtn').innerHTML =
    tab === 'scheduled'
      ? '<i class="fas fa-plus"></i> Lançamento'
      : '<i class="fas fa-credit-card"></i> Parcelado';
  if (tab === 'scheduled') renderScheduledList();
  else renderInstallmentsList();
}

// ─────────────────────────────────────────────
//  SCHEDULED MODAL (add / edit)
// ─────────────────────────────────────────────
function openScheduledModal(type = 'expense') {
  editScheduledId = null;
  document.getElementById('schedEditId').value        = '';
  document.getElementById('schedAmount').value        = '';
  document.getElementById('schedDescription').value   = '';
  document.getElementById('schedDueDate').value       = '';
  document.getElementById('schedNotes').value         = '';
  document.getElementById('schedRecurrence').value    = 'none';
  document.getElementById('schedModalTitle').textContent = 'Novo Lançamento Futuro';
  document.getElementById('schedDeleteBtn').style.display = 'none';

  // tabs de tipo
  document.querySelectorAll('#schedTypeTabs .type-tab').forEach(b =>
    b.classList.toggle('active', b.dataset.type === type));
  schedCurrentType = type;

  populateSchedAccounts();
  renderSchedCategoryPicker(type);
  schedCategoryId = null;

  openModal('schedModalOverlay', 'schedModal');
}

function openEditScheduled(id) {
  const s = DB.scheduled.getById(id);
  if (!s) return;
  editScheduledId = id;

  document.getElementById('schedEditId').value        = id;
  document.getElementById('schedAmount').value        = formatInputValue(s.amount);
  document.getElementById('schedDescription').value   = s.description || '';
  document.getElementById('schedDueDate').value       = s.dueDate || '';
  document.getElementById('schedNotes').value         = s.notes || '';
  document.getElementById('schedRecurrence').value    = s.recurrence || 'none';
  document.getElementById('schedModalTitle').textContent = 'Editar Lançamento';
  document.getElementById('schedDeleteBtn').style.display = '';

  schedCurrentType = s.type;
  document.querySelectorAll('#schedTypeTabs .type-tab').forEach(b =>
    b.classList.toggle('active', b.dataset.type === s.type));

  schedCategoryId = s.categoryId;
  populateSchedAccounts(s.accountId);
  renderSchedCategoryPicker(s.type, s.categoryId);

  openModal('schedModalOverlay', 'schedModal');
}

function closeScheduledModal() { closeModal('schedModalOverlay', 'schedModal'); }

let schedCurrentType = 'expense';
let schedCategoryId  = null;

function setSchedType(type, btn) {
  schedCurrentType = type;
  document.querySelectorAll('#schedTypeTabs .type-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  schedCategoryId = null;
  renderSchedCategoryPicker(type);
}

function renderSchedCategoryPicker(type, selectedId = null) {
  const picker = document.getElementById('schedCategoryPicker');
  if (!picker) return;
  const cats = DB.categories.getByType(type);
  if (!selectedId && !schedCategoryId && cats.length) schedCategoryId = cats[0].id;
  picker.innerHTML = cats.map(c => `
    <div class="cat-pick-item ${c.id === (selectedId || schedCategoryId) ? 'selected' : ''}"
         onclick="selectSchedCategory('${c.id}', this)">
      <span class="cat-pick-icon">${c.icon}</span>
      <span class="cat-pick-name">${escHtml(c.name)}</span>
    </div>`).join('');
}

function selectSchedCategory(id, el) {
  schedCategoryId = id;
  document.querySelectorAll('#schedCategoryPicker .cat-pick-item').forEach(e => e.classList.remove('selected'));
  el.classList.add('selected');
}

function populateSchedAccounts(selectedId = '') {
  const accs = DB.accounts.getAll();
  const opts = accs.map(a => `<option value="${a.id}" ${a.id === selectedId ? 'selected' : ''}>${escHtml(a.name)}</option>`).join('');
  const sel  = document.getElementById('schedAccount');
  if (sel) sel.innerHTML = opts || '<option value="">Sem conta</option>';
}

function saveScheduled() {
  const editId = document.getElementById('schedEditId').value;
  const amount = parseFloat(document.getElementById('schedAmount').value.replace(',', '.'));
  const desc   = document.getElementById('schedDescription').value.trim();
  const due    = document.getElementById('schedDueDate').value;
  const rec    = document.getElementById('schedRecurrence').value;
  const acct   = document.getElementById('schedAccount').value;
  const notes  = document.getElementById('schedNotes').value.trim();

  if (!amount || amount <= 0) { showToast('Informe o valor', 'error'); return; }
  if (!due)                   { showToast('Informe a data de vencimento', 'error'); return; }
  if (!desc)                  { showToast('Informe a descrição', 'error'); return; }

  const data = {
    type:        schedCurrentType,
    amount,
    description: desc,
    categoryId:  schedCategoryId,
    accountId:   acct,
    dueDate:     due,
    recurrence:  rec,
    notes
  };

  if (editId) {
    DB.scheduled.update(editId, data);
    showToast('Lançamento atualizado!', 'success');
  } else {
    DB.scheduled.add(data);
    showToast('Lançamento criado!', 'success');
  }

  closeScheduledModal();
  renderAgenda();
  updateNotifBadge();
}

function deleteScheduledConfirm(id) {
  const s = DB.scheduled.getById(id);
  openConfirm('Excluir Lançamento', `Excluir "${escHtml(s?.description || 'este lançamento')}"?`, () => {
    DB.scheduled.delete(id);
    showToast('Lançamento excluído', 'info');
    renderAgenda();
    updateNotifBadge();
  });
}

function deleteCurrentScheduled() {
  const id = document.getElementById('schedEditId').value;
  if (!id) return;
  deleteScheduledConfirm(id);
  closeScheduledModal();
}

function markScheduledPaid(id) {
  const s = DB.scheduled.getById(id);
  if (!s) return;
  openConfirm(
    'Marcar como Pago',
    `Confirmar pagamento de "${escHtml(s.description)}" — ${formatCurrency(s.amount)}?`,
    () => {
      const tx = DB.scheduled.markPaid(id);
      if (s.installmentGroupId) DB.installments.updatePaidCount(s.installmentGroupId);
      showToast('Pagamento registrado! ✅', 'success');
      renderAgenda();
      renderDashboard();
      updateNotifBadge();
    }
  );
}

// ─────────────────────────────────────────────
//  INSTALLMENT MODAL
// ─────────────────────────────────────────────
let instCategoryId = null;

function openInstallmentModal() {
  document.getElementById('instEditId').value        = '';
  document.getElementById('instTotalAmount').value   = '';
  document.getElementById('instCount').value         = '2';
  document.getElementById('instDescription').value   = '';
  document.getElementById('instFirstDue').value      = '';
  document.getElementById('instNotes').value         = '';
  instCategoryId = null;

  populateInstAccounts();
  renderInstCategoryPicker();
  updateInstallmentPreview();

  openModal('instModalOverlay', 'instModal');
}

function closeInstallmentModal() { closeModal('instModalOverlay', 'instModal'); }

function populateInstAccounts(selectedId = '') {
  const accs = DB.accounts.getAll()
    .filter(a => a.type === 'credit' || a.type === 'checking' || a.type === 'wallet');
  const allAccs = DB.accounts.getAll();
  const opts = allAccs.map(a => `<option value="${a.id}" ${a.id === selectedId ? 'selected' : ''}>${escHtml(a.name)}</option>`).join('');
  const sel  = document.getElementById('instAccount');
  if (sel) sel.innerHTML = opts || '<option value="">Sem conta</option>';
}

function renderInstCategoryPicker(selectedId = null) {
  const picker = document.getElementById('instCategoryPicker');
  if (!picker) return;
  const cats = DB.categories.getByType('expense');
  if (!selectedId && !instCategoryId && cats.length) instCategoryId = cats[0].id;
  picker.innerHTML = cats.map(c => `
    <div class="cat-pick-item ${c.id === (selectedId || instCategoryId) ? 'selected' : ''}"
         onclick="selectInstCategory('${c.id}', this)">
      <span class="cat-pick-icon">${c.icon}</span>
      <span class="cat-pick-name">${escHtml(c.name)}</span>
    </div>`).join('');
}

function selectInstCategory(id, el) {
  instCategoryId = id;
  document.querySelectorAll('#instCategoryPicker .cat-pick-item').forEach(e => e.classList.remove('selected'));
  el.classList.add('selected');
}

function updateInstallmentPreview() {
  const total = parseFloat(document.getElementById('instTotalAmount')?.value.replace(',', '.') || 0);
  const count = parseInt(document.getElementById('instCount')?.value || 1);
  const prev  = document.getElementById('instPreview');
  if (!prev) return;
  if (total > 0 && count > 0) {
    const each = (total / count).toFixed(2).replace('.', ',');
    prev.textContent = `= ${count}x de R$ ${each}`;
    prev.style.color = 'var(--accent-green)';
  } else {
    prev.textContent = '';
  }
}

function saveInstallment() {
  const total  = parseFloat(document.getElementById('instTotalAmount').value.replace(',', '.'));
  const count  = parseInt(document.getElementById('instCount').value);
  const desc   = document.getElementById('instDescription').value.trim();
  const due    = document.getElementById('instFirstDue').value;
  const acct   = document.getElementById('instAccount').value;
  const notes  = document.getElementById('instNotes').value.trim();

  if (!total || total <= 0) { showToast('Informe o valor total', 'error'); return; }
  if (!count || count < 1)  { showToast('Informe o número de parcelas', 'error'); return; }
  if (!desc)                { showToast('Informe a descrição', 'error'); return; }
  if (!due)                 { showToast('Informe a data da 1ª parcela', 'error'); return; }

  DB.installments.add({
    description:      desc,
    totalAmount:      total,
    installmentCount: count,
    firstDueDate:     due,
    categoryId:       instCategoryId,
    accountId:        acct,
    notes
  });

  showToast(`Parcelado em ${count}x criado! 💳`, 'success');
  closeInstallmentModal();
  renderAgenda();
  updateNotifBadge();
}

function deleteInstallmentConfirm(id) {
  const g = DB.installments.getById(id);
  openConfirm(
    'Excluir Parcelamento',
    `Excluir "${escHtml(g?.description || 'este parcelamento')}" e todas as parcelas pendentes?`,
    () => {
      DB.installments.delete(id);
      showToast('Parcelamento excluído', 'info');
      renderAgenda();
      updateNotifBadge();
    }
  );
}

// ─────────────────────────────────────────────
//  SHOW PARCELAS DETAIL MODAL
// ─────────────────────────────────────────────
function showInstallmentParcelas(groupId) {
  const g = DB.installments.getById(groupId);
  if (!g) return;

  const parcelas = DB.scheduled.getAll()
    .filter(s => s.installmentGroupId === groupId)
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate));

  const today = new Date().toISOString().slice(0, 10);
  const days  = DB.settings.get().notifyDaysBefore ?? 3;
  const lim   = new Date(); lim.setDate(lim.getDate() + days);
  const limStr = lim.toISOString().slice(0, 10);

  const rows = parcelas.map(p => {
    const dueFmt = p.dueDate
      ? new Date(p.dueDate + 'T12:00:00').toLocaleDateString('pt-BR', { day:'2-digit', month:'short', year:'2-digit' })
      : '—';
    const isOverdue = p.status === 'pending' && p.dueDate < today;
    const isSoon    = p.status === 'pending' && p.dueDate >= today && p.dueDate <= limStr;
    const color     = p.status === 'paid' ? 'var(--accent-green)' : isOverdue ? 'var(--accent-red)' : isSoon ? 'var(--accent-yellow)' : 'var(--text-secondary)';
    const icon      = p.status === 'paid' ? '✅' : isOverdue ? '⚠️' : isSoon ? '🔔' : '⏳';
    return `
    <div class="parcela-row" style="border-color:${color}22">
      <span class="parcela-num">${icon} Parc. ${p.installmentIndex}/${p.installmentTotal}</span>
      <span class="parcela-date" style="color:${color}">${dueFmt}</span>
      <span class="parcela-amt">${formatCurrency(p.amount)}</span>
      ${p.status === 'pending'
        ? `<button class="parcela-pay-btn" onclick="markScheduledPaid('${p.id}'); closeParcelasModal()">Pagar</button>`
        : `<span class="parcela-status-label" style="color:${color}">${p.status === 'paid' ? 'Pago' : 'Cancelado'}</span>`
      }
    </div>`;
  }).join('');

  document.getElementById('parcelasModalTitle').textContent = g.description;
  document.getElementById('parcelasModalContent').innerHTML = rows ||
    '<p class="empty-text">Nenhuma parcela encontrada</p>';

  openModal('parcelasModalOverlay', 'parcelasModal');
}

function closeParcelasModal() { closeModal('parcelasModalOverlay', 'parcelasModal'); }

// ─────────────────────────────────────────────
//  NOTIFICATIONS
// ─────────────────────────────────────────────
function checkNotifications() {
  const days    = DB.settings.get().notifyDaysBefore ?? 3;
  const dueSoon = DB.scheduled.getDueSoon(days);
  const overdue = DB.scheduled.getOverdue();
  const total   = dueSoon.length + overdue.length;
  updateNotifBadge(total);

  // Browser Notification API (se permitido)
  if (total > 0 && 'Notification' in window && Notification.permission === 'granted') {
    const msgs = [];
    if (overdue.length) msgs.push(`${overdue.length} lançamento(s) vencido(s)!`);
    if (dueSoon.length) msgs.push(`${dueSoon.length} vencendo nos próximos ${days} dias.`);
    new Notification('FinanceApp 💰', {
      body:  msgs.join(' '),
      icon:  'images/icon-512.png',
      badge: 'images/icon-512.png'
    });
  }
  return total;
}

function updateNotifBadge(count) {
  if (count === undefined) {
    const days    = DB.settings.get().notifyDaysBefore ?? 3;
    const dueSoon = DB.scheduled.getDueSoon(days);
    const overdue = DB.scheduled.getOverdue();
    count = dueSoon.length + overdue.length;
  }

  // Header bell badge
  const badge = document.getElementById('notifBadge');
  if (badge) {
    if (count > 0) { badge.textContent = count > 9 ? '9+' : count; badge.style.display = ''; }
    else           { badge.style.display = 'none'; }
  }
  // Bottom nav Agenda badge
  const navBadge = document.getElementById('agendaNavBadge');
  if (navBadge) {
    if (count > 0) { navBadge.textContent = count > 9 ? '9+' : count; navBadge.style.display = ''; }
    else           { navBadge.style.display = 'none'; }
  }
  // Drawer badge
  const drawerBadge = document.getElementById('drawerAgendaBadge');
  if (drawerBadge) {
    if (count > 0) { drawerBadge.textContent = count > 9 ? '9+' : count; drawerBadge.style.display = ''; }
    else           { drawerBadge.style.display = 'none'; }
  }
}

function requestNotificationPermission() {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission().then(perm => {
      if (perm === 'granted') showToast('Notificações ativadas! 🔔', 'success');
    });
  }
}
