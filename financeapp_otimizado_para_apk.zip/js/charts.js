/**
 * FinanceApp — Charts Module (Chart.js wrappers)
 */

const Charts = (() => {
  let dashChart = null;
  let barChart  = null;
  let pieChart  = null;
  let lineChart = null;

  const GRID_COLOR   = 'rgba(51,65,85,.6)';
  const TEXT_COLOR   = '#94a3b8';
  const FONT_FAMILY  = "'Inter', sans-serif";

  Chart.defaults.color = TEXT_COLOR;
  Chart.defaults.font.family = FONT_FAMILY;

  function destroyAll() {
    [dashChart, barChart, pieChart, lineChart].forEach(c => { if (c) c.destroy(); });
  }

  // ── Dashboard: last 7 days bar
  function renderDashboard(transactions) {
    const ctx = document.getElementById('dashboardChart');
    if (!ctx) return;
    if (dashChart) dashChart.destroy();

    const days = [];
    const incomeData = [];
    const expenseData = [];

    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const label = d.toLocaleDateString('pt-BR', { weekday: 'short' });
      const dateStr = d.toISOString().slice(0, 10);
      days.push(label);

      const dayTx = transactions.filter(t => t.date === dateStr);
      incomeData.push(dayTx.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0));
      expenseData.push(dayTx.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0));
    }

    dashChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: days,
        datasets: [
          {
            label: 'Receitas',
            data: incomeData,
            backgroundColor: 'rgba(16,185,129,.7)',
            borderRadius: 6,
            borderSkipped: false,
          },
          {
            label: 'Despesas',
            data: expenseData,
            backgroundColor: 'rgba(239,68,68,.7)',
            borderRadius: 6,
            borderSkipped: false,
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        interaction: { intersect: false, mode: 'index' },
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, padding: 12, font: { size: 11 } } },
          tooltip: {
            callbacks: {
              label: ctx => ' ' + formatCurrency(ctx.raw)
            }
          }
        },
        scales: {
          x: { grid: { color: GRID_COLOR }, ticks: { font: { size: 11 } } },
          y: {
            grid: { color: GRID_COLOR },
            ticks: {
              font: { size: 11 },
              callback: v => formatCurrencyShort(v)
            }
          }
        }
      }
    });
  }

  // ── Reports bar: monthly income vs expense
  function renderBar(labels, incomeData, expenseData) {
    const ctx = document.getElementById('barChart');
    if (!ctx) return;
    if (barChart) barChart.destroy();

    barChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Receitas',
            data: incomeData,
            backgroundColor: 'rgba(16,185,129,.75)',
            borderRadius: 6,
            borderSkipped: false,
          },
          {
            label: 'Despesas',
            data: expenseData,
            backgroundColor: 'rgba(239,68,68,.75)',
            borderRadius: 6,
            borderSkipped: false,
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        interaction: { intersect: false, mode: 'index' },
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, padding: 12, font: { size: 11 } } },
          tooltip: { callbacks: { label: ctx => ' ' + formatCurrency(ctx.raw) } }
        },
        scales: {
          x: { grid: { color: GRID_COLOR }, ticks: { font: { size: 11 } } },
          y: {
            grid: { color: GRID_COLOR },
            ticks: { font: { size: 11 }, callback: v => formatCurrencyShort(v) }
          }
        }
      }
    });
  }

  // ── Pie: expenses by category
  function renderPie(categories, amounts) {
    const ctx = document.getElementById('pieChart');
    if (!ctx) return;
    if (pieChart) pieChart.destroy();

    const colors = [
      '#ef4444','#f59e0b','#10b981','#3b82f6','#8b5cf6',
      '#ec4899','#06b6d4','#84cc16','#f43f5e','#a78bfa',
    ];

    pieChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: categories,
        datasets: [{
          data: amounts,
          backgroundColor: colors.slice(0, categories.length),
          borderColor: '#1e293b',
          borderWidth: 3,
          hoverOffset: 6,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        cutout: '60%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: { boxWidth: 12, padding: 10, font: { size: 11 } }
          },
          tooltip: {
            callbacks: {
              label: ctx => ` ${ctx.label}: ${formatCurrency(ctx.raw)} (${Math.round(ctx.parsed / ctx.dataset.data.reduce((a,b)=>a+b,0) * 100)}%)`
            }
          }
        }
      }
    });
  }

  // ── Line: balance evolution
  function renderLine(labels, balances) {
    const ctx = document.getElementById('lineChart');
    if (!ctx) return;
    if (lineChart) lineChart.destroy();

    const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 200);
    gradient.addColorStop(0, 'rgba(16,185,129,.35)');
    gradient.addColorStop(1, 'rgba(16,185,129,.0)');

    lineChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Saldo',
          data: balances,
          borderColor: '#10b981',
          backgroundColor: gradient,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: '#10b981',
          pointRadius: 4,
          pointHoverRadius: 6,
          borderWidth: 2,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        interaction: { intersect: false, mode: 'index' },
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: ctx => ' ' + formatCurrency(ctx.raw) } }
        },
        scales: {
          x: { grid: { color: GRID_COLOR }, ticks: { font: { size: 11 } } },
          y: {
            grid: { color: GRID_COLOR },
            ticks: { font: { size: 11 }, callback: v => formatCurrencyShort(v) }
          }
        }
      }
    });
  }

  return { renderDashboard, renderBar, renderPie, renderLine, destroyAll };
})();

// ---- Helpers (shared) ----
function formatCurrency(val) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);
}
function formatCurrencyShort(val) {
  if (Math.abs(val) >= 1000) return 'R$' + (val/1000).toFixed(1) + 'k';
  return 'R$' + val.toFixed(0);
}
