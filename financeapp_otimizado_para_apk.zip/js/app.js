/**
 * FinanceApp — Main Application Logic (Multi-User)
 */

// ─────────────────────────────────────────────
//  STATE
// ─────────────────────────────────────────────
let currentPage    = 'pageDashboard';
let currentTxType  = 'expense';
let currentCatType = 'expense';
let currentPeriod  = 'month';
let selectedCatIcon  = '🏷️';
let selectedCatColor = '#10b981';
let selectedGoalIcon = '🎯';
let selectedAccColor = '#10b981';
let txCategoryId   = null;
let balanceVisible = true;
let deferredInstallPrompt = null;
let filterVisible  = false;

const pageNames = {
  pageDashboard:    'Dashboard',
  pageTransactions: 'Transações',
  pageBudgets:      'Orçamentos',
  pageGoals:        'Metas',
  pageAgenda:       'Agenda & Vencimentos',
  pageReports:      'Relatórios',
  pageSettings:     'Configurações',
};

// ─────────────────────────────────────────────
//  BOOT
// ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    document.getElementById('splashScreen').classList.add('hidden');
    const user = Auth.currentUser();
    if (user) {
      DB.reset();
      showApp();
    } else {
      showAuthScreen();
    }
  }, 1800);
});

function showAuthScreen() {
  document.getElementById('authScreen').classList.remove('hidden');
  document.getElementById('app').classList.add('hidden');
}

function showApp() {
  document.getElementById('authScreen').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  init();
}

// ─────────────────────────────────────────────
//  AUTH HANDLERS
// ─────────────────────────────────────────────
function switchAuthTab(tab) {
  const isLogin = tab === 'login';
  document.getElementById('tabLoginBtn').classList.toggle('active', isLogin);
  document.getElementById('tabRegisterBtn').classList.toggle('active', !isLogin);
  document.getElementById('loginForm').classList.toggle('hidden', !isLogin);
  document.getElementById('registerForm').classList.toggle('hidden', isLogin);
  clearAuthErrors();
}

function clearAuthErrors() {
  ['loginError', 'registerError'].forEach(id => {
    const el = document.getElementById(id);
    el.textContent = '';
    el.classList.remove('visible');
  });
}

function showAuthError(id, msg) {
  const el = document.getElementById(id);
  el.textContent = msg;
  el.classList.add('visible');
}

function doLogin() {
  const email    = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  clearAuthErrors();

  if (!email || !password) {
    showAuthError('loginError', 'Preencha e-mail e senha.'); return;
  }
  const result = Auth.login({ email, password });
  if (!result.ok) {
    showAuthError('loginError', result.error); return;
  }
  DB.reset();
  showApp();
}

function doRegister() {
  const name     = document.getElementById('regName').value.trim();
  const email    = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;
  const confirm  = document.getElementById('regConfirm').value;
  clearAuthErrors();

  if (!name)     { showAuthError('registerError', 'Informe seu nome.'); return; }
  if (!email)    { showAuthError('registerError', 'Informe seu e-mail.'); return; }
  if (!password) { showAuthError('registerError', 'Informe uma senha.'); return; }
  if (password.length < 6) { showAuthError('registerError', 'A senha deve ter pelo menos 6 caracteres.'); return; }
  if (password !== confirm) { showAuthError('registerError', 'As senhas não coincidem.'); return; }

  const result = Auth.register({ name, email, password });
  if (!result.ok) {
    showAuthError('registerError', result.error); return;
  }
  DB.reset();
  showApp();
}

function togglePwd(inputId, btn) {
  const input = document.getElementById(inputId);
  const icon  = btn.querySelector('i');
  if (input.type === 'password') {
    input.type = 'text';
    icon.className = 'fas fa-eye-slash';
  } else {
    input.type = 'password';
    icon.className = 'fas fa-eye';
  }
}

// ─────────────────────────────────────────────
//  PROFILE MODAL
// ─────────────────────────────────────────────
function openProfileModal() {
  const user = Auth.currentUser();
  if (!user) return;
  document.getElementById('profileBigAvatar').textContent = user.avatar || user.name[0].toUpperCase();
  document.getElementById('profileModalName').textContent  = user.name;
  document.getElementById('profileModalEmail').textContent = user.email;
  document.getElementById('profileNameInput').value = user.name;
  document.getElementById('profileEmailHidden').value = user.email;
  document.getElementById('profileOldPwd').value    = '';
  document.getElementById('profileNewPwd').value    = '';
  document.getElementById('profileConfirmPwd').value = '';
  hideProfilePwdError();
  openModal('profileModalOverlay', 'profileModal');
}

function closeProfileModal() { closeModal('profileModalOverlay', 'profileModal'); }

function saveProfileName() {
  const name = document.getElementById('profileNameInput').value.trim();
  if (!name) { showToast('Informe o nome', 'error'); return; }
  Auth.updateProfile({ name });
  updateUserUI();
  document.getElementById('profileModalName').textContent  = name;
  showToast('Nome atualizado!', 'success');
}

function saveProfilePassword() {
  const oldPwd  = document.getElementById('profileOldPwd').value;
  const newPwd  = document.getElementById('profileNewPwd').value;
  const confirm = document.getElementById('profileConfirmPwd').value;
  hideProfilePwdError();

  if (!oldPwd || !newPwd) { showProfilePwdError('Preencha todos os campos.'); return; }
  if (newPwd.length < 6)  { showProfilePwdError('Nova senha deve ter ao menos 6 caracteres.'); return; }
  if (newPwd !== confirm)  { showProfilePwdError('As senhas não coincidem.'); return; }

  const res = Auth.changePassword(oldPwd, newPwd);
  if (!res.ok) { showProfilePwdError(res.error); return; }
  document.getElementById('profileOldPwd').value    = '';
  document.getElementById('profileNewPwd').value    = '';
  document.getElementById('profileConfirmPwd').value = '';
  showToast('Senha alterada com sucesso!', 'success');
}

function showProfilePwdError(msg) {
  const el = document.getElementById('profilePwdError');
  el.textContent = msg; el.classList.add('visible');
}
function hideProfilePwdError() {
  const el = document.getElementById('profilePwdError');
  el.textContent = ''; el.classList.remove('visible');
}

// ─────────────────────────────────────────────
//  LOGOUT
// ─────────────────────────────────────────────
function confirmLogout() {
  closeProfileModal();
  closeDrawer();
  openConfirm('Sair da Conta', 'Deseja realmente sair da sua conta?', () => {
    Auth.logout();
    DB.reset();
    location.reload();
  });
}

// ─────────────────────────────────────────────
//  INIT (after login)
// ─────────────────────────────────────────────
function init() {
  updateUserUI();
  loadSettings();
  renderDashboard();
  renderTransactionsPage();
  renderBudgets();
  renderGoals();
  renderSettings();

  // Service Worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  }

  // Install PWA
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
    const btn = document.getElementById('installBtn');
    if (btn) btn.style.display = 'flex';
  });

  document.getElementById('menuBtn').addEventListener('click', openDrawer);
  document.getElementById('toggleBalance').addEventListener('click', toggleBalanceVisibility);
  document.getElementById('profileBtn').addEventListener('click', openProfileModal);

  // Botão de notificações → abre a página de agenda
  const notifBtn = document.getElementById('notifBtn');
  if (notifBtn) {
    notifBtn.addEventListener('click', () => {
      navigateTo('pageAgenda');
    });
  }

  const installBtn = document.getElementById('installBtn');
  if (installBtn) {
    installBtn.addEventListener('click', async () => {
      if (deferredInstallPrompt) {
        deferredInstallPrompt.prompt();
        const { outcome } = await deferredInstallPrompt.userChoice;
        if (outcome === 'accepted') showToast('App instalado! 🎉', 'success');
        deferredInstallPrompt = null;
      }
    });
  }

  document.getElementById('txDate').value = todayISO();
  document.getElementById('currentMonth').textContent =
    new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

  // Pré-seleciona o mês atual no filtro
  const filterMonth = document.getElementById('filterMonth');
  if (filterMonth) {
    const now = new Date();
    filterMonth.value = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  }

  setupIconPicker('goalIconPicker', v => selectedGoalIcon = v);

  // Notificações de vencimento
  updateNotifBadge();
  requestNotificationPermission();
  // Checa novamente a cada 30min
  setInterval(updateNotifBadge, 30 * 60 * 1000);
}

function updateUserUI() {
  const user = Auth.currentUser();
  if (!user) return;
  const letter = user.avatar || user.name[0].toUpperCase();
  const el = id => document.getElementById(id);

  if (el('avatarIcon'))     el('avatarIcon').textContent     = letter;
  if (el('drawerAvatar'))   el('drawerAvatar').textContent   = letter;
  if (el('drawerUserName')) el('drawerUserName').textContent = user.name;
  if (el('drawerUserEmail'))el('drawerUserEmail').textContent= user.email;
  if (el('sucAvatar'))      el('sucAvatar').textContent      = letter;
  if (el('sucName'))        el('sucName').textContent        = user.name;
  if (el('sucEmail'))       el('sucEmail').textContent       = user.email;

  // Avatar com cor baseada no nome
  const hue = [...user.name].reduce((acc, c) => acc + c.charCodeAt(0), 0) % 360;
  const avatarStyle = `background: hsl(${hue}, 60%, 40%)`;
  if (el('avatarIcon'))   el('avatarIcon').setAttribute('style', `${avatarStyle};display:flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;font-size:14px;font-weight:700;color:#fff`);
  if (el('drawerAvatar')) el('drawerAvatar').setAttribute('style', `${avatarStyle};width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#fff;flex-shrink:0`);
  if (el('sucAvatar'))    el('sucAvatar').setAttribute('style', `${avatarStyle};width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:800;color:#fff`);
  if (el('profileBigAvatar')) el('profileBigAvatar').setAttribute('style', `${avatarStyle};width:72px;height:72px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:30px;font-weight:800;color:#fff;margin:0 auto 8px`);
}

// ─────────────────────────────────────────────
//  SETTINGS LOAD
// ─────────────────────────────────────────────
function loadSettings() {
  const s = DB.settings.get();
  balanceVisible = s.balanceVisible !== false;
  if (!balanceVisible) {
    document.getElementById('totalBalance').classList.add('blurred');
    document.getElementById('balanceEyeIcon').className = 'fas fa-eye-slash';
  }
}

// ─────────────────────────────────────────────
//  NAVIGATION
// ─────────────────────────────────────────────
function navigateTo(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  document.querySelectorAll('.nav-item[data-page]').forEach(btn =>
    btn.classList.toggle('active', btn.dataset.page === pageId));
  document.getElementById('headerTitle').textContent = pageNames[pageId] || '';
  currentPage = pageId;

  if (pageId === 'pageReports')      renderReports();
  if (pageId === 'pageBudgets')      renderBudgets();
  if (pageId === 'pageGoals')        renderGoals();
  if (pageId === 'pageSettings')     renderSettings();
  if (pageId === 'pageTransactions') renderTransactionsPage();
  if (pageId === 'pageAgenda')       renderAgenda();
}

// ─────────────────────────────────────────────
//  DRAWER
// ─────────────────────────────────────────────
function openDrawer() {
  document.getElementById('sideDrawer').classList.add('open');
  document.getElementById('drawerOverlay').classList.add('visible');
  document.getElementById('drawerBalance').textContent = formatCurrency(DB.accounts.getTotalBalance());
}
function closeDrawer() {
  document.getElementById('sideDrawer').classList.remove('open');
  document.getElementById('drawerOverlay').classList.remove('visible');
}

// ─────────────────────────────────────────────
//  BALANCE VISIBILITY
// ─────────────────────────────────────────────
function toggleBalanceVisibility() {
  balanceVisible = !balanceVisible;
  DB.settings.set({ balanceVisible });
  document.getElementById('totalBalance').classList.toggle('blurred', !balanceVisible);
  document.getElementById('balanceEyeIcon').className = balanceVisible ? 'fas fa-eye' : 'fas fa-eye-slash';
}

// ─────────────────────────────────────────────
//  DASHBOARD
// ─────────────────────────────────────────────
function renderDashboard() {
  const now   = new Date();
  const year  = now.getFullYear();
  const month = now.getMonth();
  const txs   = DB.transactions.getByMonth(year, month);
  const allTx = DB.transactions.getAll();

  const income  = txs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const expense = txs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const total   = DB.accounts.getTotalBalance();

  document.getElementById('totalBalance').textContent = formatCurrency(total);
  document.getElementById('totalIncome').textContent  = formatCurrency(income);
  document.getElementById('totalExpense').textContent = formatCurrency(expense);

  renderRecentTransactions(allTx.slice(0, 8));
  renderBudgetsOverview();
  renderDashUpcoming();
  Charts.renderDashboard(allTx);
}

function renderRecentTransactions(txs) {
  const el = document.getElementById('recentTransactions');
  if (!txs.length) { el.innerHTML = '<p class="empty-text">Nenhuma transação ainda</p>'; return; }
  el.innerHTML = txs.map(tx => buildTxCard(tx)).join('');
}

function renderDashUpcoming() {
  const el = document.getElementById('dashUpcoming');
  if (!el) return;
  const days    = DB.settings.get().notifyDaysBefore ?? 3;
  const overdue = DB.scheduled.getOverdue();
  const soon    = DB.scheduled.getDueSoon(days);
  // merge & deduplicate
  const map = new Map();
  [...overdue, ...soon].forEach(s => map.set(s.id, s));
  const items = [...map.values()].sort((a, b) => a.dueDate.localeCompare(b.dueDate)).slice(0, 5);

  if (!items.length) {
    el.innerHTML = '<p class="empty-text">✅ Nenhum vencimento próximo</p>';
    return;
  }
  const today = new Date().toISOString().slice(0, 10);
  el.innerHTML = items.map(s => {
    const isOverdue = s.dueDate < today;
    const cat    = DB.categories.getById(s.categoryId);
    const icon   = cat ? cat.icon : '📋';
    const color  = isOverdue ? 'var(--accent-red)' : 'var(--accent-yellow)';

    // Calcular dias
    const due = new Date(s.dueDate + 'T12:00:00');
    const now = new Date();
    const diffDays = Math.round((due - now) / (1000*60*60*24));
    let daysLabel;
    if (diffDays < 0) daysLabel = `${Math.abs(diffDays)}d atraso`;
    else if (diffDays === 0) daysLabel = 'Hoje!';
    else daysLabel = `em ${diffDays}d`;

    const dueFmt = new Date(s.dueDate + 'T12:00:00').toLocaleDateString('pt-BR', { day:'2-digit', month:'short' });
    return `
    <div class="dash-upcoming-item" onclick="navigateTo('pageAgenda')" style="border-left:3px solid ${color}">
      <span class="due-icon">${icon}</span>
      <div class="due-info">
        <span class="due-desc">${escHtml(s.description)}</span>
        <span class="due-meta">📅 ${dueFmt}</span>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px">
        <span class="due-amt" style="color:${s.type==='income'?'var(--accent-green)':'var(--accent-red)'}">
          ${s.type === 'income' ? '+' : '-'} ${formatCurrency(s.amount)}
        </span>
        <span class="days-remaining-chip ${isOverdue?'overdue':diffDays<=2?'soon':'ok'}">${daysLabel}</span>
      </div>
    </div>`;
  }).join('');
}

// ─────────────────────────────────────────────
//  TRANSACTIONS PAGE
// ─────────────────────────────────────────────
function renderTransactionsPage() {
  populateCategoryFilter();
  renderFilteredTransactions();
}

function renderFilteredTransactions() {
  const allTx  = DB.transactions.getAll();
  const search = (document.getElementById('searchInput')?.value || '').toLowerCase();
  const typeF  = document.getElementById('filterType')?.value || '';
  const catF   = document.getElementById('filterCategory')?.value || '';
  const monthF = document.getElementById('filterMonth')?.value || '';

  let txs = allTx;
  if (typeF)  txs = txs.filter(t => t.type === typeF);
  if (catF)   txs = txs.filter(t => t.categoryId === catF);
  if (monthF) txs = txs.filter(t => t.date && t.date.startsWith(monthF));
  if (search) txs = txs.filter(t =>
    (t.description || '').toLowerCase().includes(search) ||
    (getCategoryName(t.categoryId) || '').toLowerCase().includes(search));

  const income  = txs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const expense = txs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  document.getElementById('txTotalIncome').textContent  = formatCurrency(income);
  document.getElementById('txTotalExpense').textContent = formatCurrency(expense);
  document.getElementById('txBalance').textContent      = formatCurrency(income - expense);

  const listEl = document.getElementById('transactionsList');
  if (!txs.length) { listEl.innerHTML = '<p class="empty-text">Nenhuma transação encontrada</p>'; return; }

  const grouped = {};
  txs.forEach(tx => {
    const key = tx.date || 'sem-data';
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(tx);
  });

  let html = '';
  Object.keys(grouped).sort((a, b) => b.localeCompare(a)).forEach(date => {
    html += `<div class="tx-date-separator">${formatDate(date)}</div>`;
    grouped[date].forEach(tx => { html += buildTxCard(tx); });
  });
  listEl.innerHTML = html;
}

function buildTxCard(tx) {
  const cat     = DB.categories.getById(tx.categoryId);
  const icon    = cat ? cat.icon : (tx.type === 'transfer' ? '🔄' : tx.type === 'income' ? '💰' : '📦');
  const color   = cat ? cat.color : (tx.type === 'income' ? '#10b981' : tx.type === 'transfer' ? '#3b82f6' : '#64748b');
  const sign    = tx.type === 'income' ? '+' : tx.type === 'expense' ? '-' : '↔';
  const catName = cat ? cat.name : (tx.type === 'transfer' ? 'Transferência' : 'Sem categoria');
  const account = DB.accounts.getById(tx.accountId);
  const accName = account ? account.name : '';

  return `
  <div class="tx-item-wrapper">
    <div class="tx-item" onclick="openEditTransaction('${tx.id}')">
      <div class="tx-icon" style="background:${color}22">${icon}</div>
      <div class="tx-info">
        <div class="tx-desc">${escHtml(tx.description || 'Sem descrição')}</div>
        <div class="tx-cat">${catName}${accName ? ' · ' + escHtml(accName) : ''}</div>
      </div>
      <div class="tx-right">
        <div class="tx-amount ${tx.type}">${sign} ${formatCurrency(tx.amount)}</div>
        <div class="tx-date">${formatDateShort(tx.date)}</div>
      </div>
      <button class="tx-del-btn" onclick="quickDeleteTransaction('${tx.id}', event)" title="Excluir">
        <i class="fas fa-trash"></i>
      </button>
    </div>
  </div>`;
}

function filterTransactions() { renderFilteredTransactions(); }

function toggleFilters() {
  filterVisible = !filterVisible;
  document.getElementById('filterPanel').style.display = filterVisible ? 'flex' : 'none';
}
function clearFilters() {
  document.getElementById('filterType').value     = '';
  document.getElementById('filterCategory').value = '';
  document.getElementById('filterMonth').value    = '';
  document.getElementById('searchInput').value    = '';
  renderFilteredTransactions();
}

function populateCategoryFilter() {
  const sel = document.getElementById('filterCategory');
  if (!sel) return;
  const cats = DB.categories.getAll();
  sel.innerHTML = '<option value="">Todas as categorias</option>' +
    cats.map(c => `<option value="${c.id}">${c.icon} ${escHtml(c.name)}</option>`).join('');
}

// ─────────────────────────────────────────────
//  TRANSACTION MODAL
// ─────────────────────────────────────────────
function openAddTransaction(type = 'expense') {
  currentTxType = type;
  document.getElementById('txEditId').value      = '';
  document.getElementById('txAmount').value      = '';
  document.getElementById('txDescription').value = '';
  document.getElementById('txNotes').value       = '';
  document.getElementById('txDate').value        = todayISO();
  txCategoryId = null;

  document.querySelectorAll('#txTypeTabs .type-tab').forEach(btn =>
    btn.classList.toggle('active', btn.dataset.type === type));
  document.getElementById('txAccountToGroup').style.display = type === 'transfer' ? '' : 'none';

  populateTxAccounts();
  renderCategoryPicker();

  document.getElementById('txModalTitle').textContent =
    type === 'income' ? 'Nova Receita' : type === 'expense' ? 'Nova Despesa' : 'Nova Transferência';
  document.getElementById('txSaveBtn').textContent = 'Salvar';
  document.getElementById('txDeleteBtn').style.display = 'none';

  openModal('txModalOverlay', 'txModal');
}

function openEditTransaction(id) {
  const tx = DB.transactions.getById(id);
  if (!tx) return;

  currentTxType = tx.type;
  document.getElementById('txEditId').value      = id;
  document.getElementById('txAmount').value      = formatInputValue(tx.amount);
  document.getElementById('txDescription').value = tx.description || '';
  document.getElementById('txNotes').value       = tx.notes || '';
  document.getElementById('txDate').value        = tx.date || todayISO();
  txCategoryId = tx.categoryId;

  document.querySelectorAll('#txTypeTabs .type-tab').forEach(btn =>
    btn.classList.toggle('active', btn.dataset.type === tx.type));
  document.getElementById('txAccountToGroup').style.display = tx.type === 'transfer' ? '' : 'none';

  populateTxAccounts(tx.accountId, tx.accountToId);
  renderCategoryPicker(tx.categoryId);

  document.getElementById('txModalTitle').textContent = 'Editar Transação';
  document.getElementById('txSaveBtn').textContent    = 'Atualizar';
  document.getElementById('txDeleteBtn').style.display = '';

  openModal('txModalOverlay', 'txModal');
}

function closeTransactionModal() { closeModal('txModalOverlay', 'txModal'); }

// Excluir a transação que está aberta no modal de edição
function deleteCurrentTransaction() {
  const id = document.getElementById('txEditId').value;
  if (!id) return;
  const tx = DB.transactions.getById(id);
  const desc = tx ? escHtml(tx.description || 'esta transação') : 'esta transação';
  openConfirm(
    'Excluir Transação',
    `Deseja excluir "${desc}"? Esta ação não pode ser desfeita.`,
    () => {
      DB.transactions.delete(id);
      closeTransactionModal();
      showToast('Transação excluída!', 'info');
      renderDashboard();
      renderTransactionsPage();
      if (currentPage === 'pageBudgets') renderBudgets();
      if (currentPage === 'pageReports') renderReports();
    }
  );
}

// Excluir direto pelo botão no card da lista
function quickDeleteTransaction(id, event) {
  event.stopPropagation(); // não abre o modal de edição
  const tx = DB.transactions.getById(id);
  const desc = tx ? escHtml(tx.description || 'esta transação') : 'esta transação';
  openConfirm(
    'Excluir Transação',
    `Deseja excluir "${desc}"? Esta ação não pode ser desfeita.`,
    () => {
      DB.transactions.delete(id);
      showToast('Transação excluída!', 'info');
      renderDashboard();
      renderTransactionsPage();
      if (currentPage === 'pageBudgets') renderBudgets();
      if (currentPage === 'pageReports') renderReports();
    }
  );
}

function setTxType(type, btn) {
  currentTxType = type;
  document.querySelectorAll('#txTypeTabs .type-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('txAccountToGroup').style.display = type === 'transfer' ? '' : 'none';
  renderCategoryPicker();
}

function renderCategoryPicker(selectedId = null) {
  const picker = document.getElementById('categoryPicker');
  const type   = currentTxType === 'transfer' ? 'expense' : currentTxType;
  const cats   = DB.categories.getByType(type);
  if (!selectedId) selectedId = txCategoryId;
  picker.innerHTML = cats.map(c => `
    <div class="cat-pick-item ${c.id === selectedId ? 'selected' : ''}" onclick="selectCategory('${c.id}', this)">
      <span class="cat-pick-icon">${c.icon}</span>
      <span class="cat-pick-name">${escHtml(c.name)}</span>
    </div>`).join('');
  if (!txCategoryId && cats.length) {
    txCategoryId = cats[0].id;
    picker.querySelector('.cat-pick-item')?.classList.add('selected');
  }
}

function selectCategory(id, el) {
  txCategoryId = id;
  document.querySelectorAll('.cat-pick-item').forEach(e => e.classList.remove('selected'));
  el.classList.add('selected');
}

function populateTxAccounts(selectedId = '', toId = '') {
  const accounts = DB.accounts.getAll();
  const opts  = accounts.map(a => `<option value="${a.id}" ${a.id === selectedId ? 'selected' : ''}>${escHtml(a.name)}</option>`).join('');
  const opts2 = accounts.map(a => `<option value="${a.id}" ${a.id === toId ? 'selected' : ''}>${escHtml(a.name)}</option>`).join('');
  document.getElementById('txAccount').innerHTML   = opts  || '<option value="">Sem conta</option>';
  document.getElementById('txAccountTo').innerHTML = opts2 || '<option value="">Sem conta</option>';
}

function saveTransaction() {
  const editId    = document.getElementById('txEditId').value;
  const amountStr = document.getElementById('txAmount').value.replace(',', '.');
  const amount    = parseFloat(amountStr);
  if (!amount || amount <= 0) { showToast('Informe um valor válido', 'error'); return; }

  const data = {
    type:       currentTxType,
    amount,
    description: document.getElementById('txDescription').value.trim() || 'Sem descrição',
    categoryId:  txCategoryId,
    accountId:   document.getElementById('txAccount').value,
    accountToId: currentTxType === 'transfer' ? document.getElementById('txAccountTo').value : null,
    date:   document.getElementById('txDate').value || todayISO(),
    notes:  document.getElementById('txNotes').value.trim(),
  };

  if (editId) {
    DB.transactions.update(editId, data);
    showToast('Transação atualizada!', 'success');
  } else {
    DB.transactions.add(data);
    showToast('Transação salva!', 'success');
  }

  closeTransactionModal();
  renderDashboard();
  if (currentPage === 'pageTransactions') renderTransactionsPage();
  if (currentPage === 'pageBudgets')      renderBudgets();
  if (currentPage === 'pageReports')      renderReports();
}

// ─────────────────────────────────────────────
//  BUDGETS
// ─────────────────────────────────────────────
function renderBudgetsOverview() { renderBudgets(); }

function renderBudgets() {
  const now     = new Date();
  const budgets = DB.budgets.getAll();
  const listEl  = document.getElementById('budgetsList');
  const ov      = document.getElementById('budgetOverview');

  if (!budgets.length) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">
      <i class="fas fa-piggy-bank"></i>
      <p>Nenhum orçamento criado</p>
      <button onclick="openBudgetModal()">Criar Orçamento</button></div>`;
    if (ov) ov.innerHTML = '<p class="empty-text">Nenhum orçamento definido</p>';
    return;
  }

  const buildBudgetItem = b => {
    const cat   = DB.categories.getById(b.categoryId);
    const icon  = cat ? cat.icon : '📦';
    const name  = cat ? cat.name : 'Categoria';
    const spent = DB.budgets.getSpent(b.categoryId, now.getFullYear(), now.getMonth());
    const pct   = b.limit > 0 ? Math.min(100, Math.round((spent / b.limit) * 100)) : 0;
    const color = pct >= 100 ? '#ef4444' : pct >= 80 ? '#f59e0b' : '#10b981';
    return { b, icon, name, spent, pct, color };
  };

  if (listEl) listEl.innerHTML = budgets.map(b => {
    const { icon, name, spent, pct, color, b: bud } = buildBudgetItem(b);
    return `
    <div class="budget-item">
      <div class="budget-header">
        <div class="budget-info"><span class="budget-icon">${icon}</span><span class="budget-name">${escHtml(name)}</span></div>
        <div class="budget-actions">
          <button class="icon-action-btn" onclick="openEditBudget('${bud.id}')"><i class="fas fa-pen"></i></button>
          <button class="icon-action-btn" onclick="deleteBudget('${bud.id}')" style="color:#ef4444"><i class="fas fa-trash"></i></button>
        </div>
      </div>
      <div class="budget-amount">Gasto: <span>${formatCurrency(spent)}</span> de ${formatCurrency(bud.limit)}</div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%; background:${color}"></div></div>
      <div class="progress-label"><span>${pct}% usado</span><span>Restam ${formatCurrency(Math.max(0, bud.limit - spent))}</span></div>
    </div>`;
  }).join('');

  if (ov) ov.innerHTML = budgets.slice(0, 3).map(b => {
    const { icon, name, spent, pct, color, b: bud } = buildBudgetItem(b);
    return `
    <div class="budget-mini">
      <div class="bm-header">
        <span class="bm-name">${icon} ${escHtml(name)}</span>
        <span class="bm-vals"><strong>${formatCurrency(spent)}</strong> / ${formatCurrency(bud.limit)}</span>
      </div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%; background:${color}"></div></div>
    </div>`;
  }).join('');
}

function openBudgetModal() {
  document.getElementById('budgetEditId').value = '';
  document.getElementById('budgetLimit').value  = '';
  populateBudgetCategories();
  openModal('budgetModalOverlay', 'budgetModal');
}
function openEditBudget(id) {
  const b = DB.budgets.getById(id);
  if (!b) return;
  document.getElementById('budgetEditId').value = id;
  document.getElementById('budgetLimit').value  = formatInputValue(b.limit);
  populateBudgetCategories(b.categoryId);
  openModal('budgetModalOverlay', 'budgetModal');
}
function closeBudgetModal() { closeModal('budgetModalOverlay', 'budgetModal'); }
function populateBudgetCategories(selected = '') {
  const cats = DB.categories.getByType('expense');
  document.getElementById('budgetCategory').innerHTML =
    cats.map(c => `<option value="${c.id}" ${c.id === selected ? 'selected' : ''}>${c.icon} ${escHtml(c.name)}</option>`).join('');
}
function saveBudget() {
  const editId     = document.getElementById('budgetEditId').value;
  const limit      = parseFloat(document.getElementById('budgetLimit').value.replace(',', '.'));
  const categoryId = document.getElementById('budgetCategory').value;
  if (!limit || limit <= 0) { showToast('Informe um limite válido', 'error'); return; }
  if (!categoryId)           { showToast('Selecione uma categoria', 'error'); return; }

  if (editId) { DB.budgets.update(editId, { limit, categoryId }); showToast('Orçamento atualizado!', 'success'); }
  else        { DB.budgets.add({ limit, categoryId });            showToast('Orçamento criado!', 'success'); }

  closeBudgetModal(); renderBudgets(); renderDashboard();
}
function deleteBudget(id) {
  openConfirm('Excluir Orçamento', 'Deseja excluir este orçamento?', () => {
    DB.budgets.delete(id); showToast('Orçamento excluído', 'info');
    renderBudgets(); renderDashboard();
  });
}

// ─────────────────────────────────────────────
//  GOALS
// ─────────────────────────────────────────────
function renderGoals() {
  const goals = DB.goals.getAll();
  const el    = document.getElementById('goalsList');
  if (!goals.length) {
    el.innerHTML = `<div class="empty-state"><i class="fas fa-bullseye"></i><p>Nenhuma meta criada</p>
      <button onclick="openGoalModal()">Criar Meta</button></div>`;
    return;
  }
  el.innerHTML = goals.map(g => {
    const pct      = g.target > 0 ? Math.min(100, Math.round((g.current / g.target) * 100)) : 0;
    const remain   = Math.max(0, g.target - g.current);
    const deadline = g.deadline ? new Date(g.deadline).toLocaleDateString('pt-BR') : '—';
    const color    = pct >= 100 ? '#10b981' : '#3b82f6';
    return `
    <div class="goal-item">
      <div class="goal-header">
        <div class="goal-info">
          <span class="goal-icon-big">${g.icon || '🎯'}</span>
          <div>
            <div class="goal-name">${escHtml(g.name)}</div>
            <div class="goal-deadline">📅 ${deadline} ${pct >= 100 ? '✅ Concluída!' : ''}</div>
          </div>
        </div>
        <div style="display:flex;gap:6px">
          <button class="icon-action-btn" onclick="openEditGoal('${g.id}')"><i class="fas fa-pen"></i></button>
          <button class="icon-action-btn" onclick="deleteGoal('${g.id}')" style="color:#ef4444"><i class="fas fa-trash"></i></button>
        </div>
      </div>
      <div class="goal-amounts">
        <div><div class="ga-label">Atual</div><div class="ga-val current">${formatCurrency(g.current)}</div></div>
        <div><div class="ga-label">Meta</div><div class="ga-val target">${formatCurrency(g.target)}</div></div>
        <div><div class="ga-label">Faltam</div><div class="ga-val remain">${formatCurrency(remain)}</div></div>
      </div>
      <div class="progress-bar" style="margin-bottom:6px">
        <div class="progress-fill" style="width:${pct}%; background:${color}"></div>
      </div>
      <div class="progress-label">
        <span class="goal-pct">${pct}% concluído</span>
        <span style="font-size:11px;color:var(--text-muted)">${formatCurrencyShort(remain)} para a meta</span>
      </div>
      ${pct < 100 ? `<button class="goal-contribute-btn" onclick="contributeGoal('${g.id}')">
        <i class="fas fa-plus-circle"></i> Adicionar Valor</button>` : ''}
    </div>`;
  }).join('');
}

function openGoalModal() {
  document.getElementById('goalEditId').value   = '';
  document.getElementById('goalName').value     = '';
  document.getElementById('goalTarget').value   = '';
  document.getElementById('goalCurrent').value  = '';
  document.getElementById('goalDate').value     = '';
  selectedGoalIcon = '🎯';
  document.querySelectorAll('#goalIconPicker .icon-opt').forEach((el, i) => el.classList.toggle('selected', i === 0));
  openModal('goalModalOverlay', 'goalModal');
}
function openEditGoal(id) {
  const g = DB.goals.getById(id);
  if (!g) return;
  document.getElementById('goalEditId').value   = id;
  document.getElementById('goalName').value     = g.name || '';
  document.getElementById('goalTarget').value   = formatInputValue(g.target);
  document.getElementById('goalCurrent').value  = formatInputValue(g.current);
  document.getElementById('goalDate').value     = g.deadline || '';
  selectedGoalIcon = g.icon || '🎯';
  document.querySelectorAll('#goalIconPicker .icon-opt').forEach(el =>
    el.classList.toggle('selected', el.dataset.icon === g.icon));
  openModal('goalModalOverlay', 'goalModal');
}
function closeGoalModal() { closeModal('goalModalOverlay', 'goalModal'); }
function saveGoal() {
  const editId   = document.getElementById('goalEditId').value;
  const name     = document.getElementById('goalName').value.trim();
  const target   = parseFloat(document.getElementById('goalTarget').value.replace(',', '.'));
  const current  = parseFloat(document.getElementById('goalCurrent').value.replace(',', '.') || 0);
  const deadline = document.getElementById('goalDate').value;
  if (!name)               { showToast('Informe o nome da meta', 'error'); return; }
  if (!target || target<=0){ showToast('Informe o valor alvo', 'error'); return; }
  const data = { name, icon: selectedGoalIcon, target, current: current || 0, deadline };
  if (editId) { DB.goals.update(editId, data); showToast('Meta atualizada!', 'success'); }
  else        { DB.goals.add(data);            showToast('Meta criada!', 'success'); }
  closeGoalModal(); renderGoals();
}
function deleteGoal(id) {
  openConfirm('Excluir Meta', 'Deseja excluir esta meta?', () => {
    DB.goals.delete(id); showToast('Meta excluída', 'info'); renderGoals();
  });
}
function contributeGoal(id) {
  const g = DB.goals.getById(id); if (!g) return;
  const amtStr = prompt(`Adicionar quanto à meta "${g.name}"?`); if (!amtStr) return;
  const amt = parseFloat(amtStr.replace(',', '.'));
  if (!amt || amt <= 0) { showToast('Valor inválido', 'error'); return; }
  DB.goals.contribute(id, amt);
  showToast(`+ ${formatCurrency(amt)} adicionado!`, 'success'); renderGoals();
}

// ─────────────────────────────────────────────
//  REPORTS
// ─────────────────────────────────────────────
function selectPeriod(period, btn) {
  currentPeriod = period;
  document.querySelectorAll('.period-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active'); renderReports();
}

function renderReports() {
  const now = new Date(), year = now.getFullYear(), month = now.getMonth();
  let txs = [], barLabels = [], barIncome = [], barExpense = [], lineLabels = [], lineBal = [];

  if (currentPeriod === 'month') {
    txs = DB.transactions.getByMonth(year, month);
    for (let w = 3; w >= 0; w--) {
      const start = new Date(now); start.setDate(now.getDate() - w * 7 - 6);
      const end   = new Date(now); end.setDate(now.getDate() - w * 7);
      const wTx   = DB.transactions.getAll().filter(t => { const d = new Date(t.date); return d >= start && d <= end; });
      barLabels.push(`Sem ${4 - w}`);
      barIncome.push(wTx.filter(t=>t.type==='income').reduce((s,t)=>s+t.amount,0));
      barExpense.push(wTx.filter(t=>t.type==='expense').reduce((s,t)=>s+t.amount,0));
    }
    for (let d = 1; d <= 30; d++) {
      const dt = new Date(year, month, d); if (dt > now) break;
      const dayTx = DB.transactions.getAll().filter(t => t.date === dt.toISOString().slice(0,10));
      const prev  = lineBal.length ? lineBal[lineBal.length - 1] : 0;
      lineBal.push(prev + dayTx.reduce((s,t)=>t.type==='income'?s+t.amount:t.type==='expense'?s-t.amount:s, 0));
      lineLabels.push(`${d}/${month+1}`);
    }
  } else {
    const periods = currentPeriod === 'quarter' ? 3 : 12;
    for (let i = periods - 1; i >= 0; i--) {
      let m = month - i, y = year;
      if (m < 0) { m += 12; y--; }
      const mTx   = DB.transactions.getByMonth(y, m);
      const label = new Date(y, m, 1).toLocaleDateString('pt-BR', { month: 'short' });
      barLabels.push(label);
      barIncome.push(mTx.filter(t=>t.type==='income').reduce((s,t)=>s+t.amount,0));
      barExpense.push(mTx.filter(t=>t.type==='expense').reduce((s,t)=>s+t.amount,0));
      txs = txs.concat(mTx);
    }
    lineLabels = barLabels; lineBal = barIncome.map((inc, i) => inc - barExpense[i]);
  }

  const income  = txs.filter(t=>t.type==='income').reduce((s,t)=>s+t.amount,0);
  const expense = txs.filter(t=>t.type==='expense').reduce((s,t)=>s+t.amount,0);
  document.getElementById('reportIncome').textContent  = formatCurrency(income);
  document.getElementById('reportExpense').textContent = formatCurrency(expense);
  document.getElementById('reportSavings').textContent = formatCurrency(income - expense);

  Charts.renderBar(barLabels, barIncome, barExpense);
  Charts.renderLine(lineLabels, lineBal);

  const catMap = {};
  txs.filter(t=>t.type==='expense').forEach(t => {
    const cat = DB.categories.getById(t.categoryId);
    const key = cat ? cat.name : 'Outros';
    catMap[key] = (catMap[key] || 0) + t.amount;
  });
  const sorted = Object.entries(catMap).sort((a, b) => b[1] - a[1]);
  Charts.renderPie(sorted.map(e=>e[0]), sorted.map(e=>e[1]));

  const total  = sorted.reduce((s, e) => s + e[1], 0);
  document.getElementById('categoryReport').innerHTML = sorted.map(([name, amt]) => {
    const pct = total ? Math.round(amt / total * 100) : 0;
    const cat = DB.categories.getAll().find(c => c.name === name);
    return `
    <div class="cat-report-item">
      <div class="cat-report-header">
        <div class="cat-report-name"><span>${cat ? cat.icon : '📦'}</span><span>${escHtml(name)}</span></div>
        <div class="cat-report-amt" style="color:var(--accent-red)">${formatCurrency(amt)}</div>
      </div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%; background:${cat ? cat.color : '#64748b'}"></div></div>
      <div class="cat-report-pct">${pct}% do total de despesas</div>
    </div>`;
  }).join('') || '<p class="empty-text">Sem despesas no período</p>';
}

// ─────────────────────────────────────────────
//  SETTINGS
// ─────────────────────────────────────────────
function renderSettings() {
  updateUserUI();
  renderCategoriesGrid();
  renderAccountsList();
  renderNotifySettings();
}

function renderNotifySettings() {
  const s = DB.settings.get();
  const el = document.getElementById('notifyDaysInput');
  if (el) el.value = s.notifyDaysBefore ?? 3;
}

function saveNotifyDays() {
  const val = parseInt(document.getElementById('notifyDaysInput')?.value || 3);
  if (isNaN(val) || val < 1) { showToast('Valor inválido', 'error'); return; }
  DB.settings.set({ notifyDaysBefore: val });
  updateNotifBadge();
  showToast('Configuração salva!', 'success');
}

function renderCategoriesGrid() {
  const grid = document.getElementById('categoriesGrid');
  if (!grid) return;
  const cats = DB.categories.getAll();

  // Separar padrão x customizadas
  const systemCats = cats.filter(c => c.system);
  const customCats = cats.filter(c => !c.system);

  let html = '';
  if (systemCats.length) {
    html += '<div class="cat-section-label">Padrão</div>';
    html += systemCats.map(c => `
      <div class="cat-chip" title="${escHtml(c.name)} (${c.type==='income'?'Receita':'Despesa'})">
        <span class="cat-dot" style="background:${c.color}"></span>
        ${c.icon} ${escHtml(c.name)}
      </div>`).join('');
  }
  if (customCats.length) {
    html += '<div class="cat-section-label" style="margin-top:8px">Minhas Categorias</div>';
    html += customCats.map(c => `
      <div class="cat-chip custom" title="${escHtml(c.name)} (${c.type==='income'?'Receita':'Despesa'})">
        <span class="cat-dot" style="background:${c.color}"></span>
        ${c.icon} ${escHtml(c.name)}
        <span class="cat-delete" onclick="deleteCategoryConfirm('${c.id}'); event.stopPropagation()">✕</span>
      </div>`).join('');
  }
  grid.innerHTML = html;
}

function renderAccountsList() {
  const list = document.getElementById('accountsList');
  if (!list) return;
  const accounts = DB.accounts.getAll();
  const accTypes = { checking:'Conta Corrente', savings:'Poupança', wallet:'Carteira', investment:'Investimentos', credit:'Cartão' };
  const total = DB.accounts.getTotalBalance();

  let html = `
  <div class="accounts-total">
    <span class="accounts-total-label">Saldo Total das Contas</span>
    <span class="accounts-total-value">${formatCurrency(total)}</span>
  </div>`;

  html += accounts.map(a => `
    <div class="account-item">
      <div class="acc-icon" style="background:${a.color}22;border:2px solid ${a.color}44">
        ${a.type==='wallet'?'👛':a.type==='savings'?'🏦':a.type==='investment'?'📈':a.type==='credit'?'💳':'🏧'}
      </div>
      <div class="acc-info">
        <div class="acc-name">${escHtml(a.name)}</div>
        <div class="acc-type">${accTypes[a.type] || a.type}</div>
      </div>
      <div class="acc-balance" style="color:${a.balance >= 0 ? 'var(--accent-green)' : 'var(--accent-red)'}">${formatCurrency(a.balance)}</div>
      <button class="icon-action-btn" onclick="openEditAccount('${a.id}')" style="margin-left:4px">
        <i class="fas fa-pen"></i>
      </button>
      <button class="icon-action-btn" onclick="deleteAccountConfirm('${a.id}')" style="color:#ef4444;margin-left:4px">
        <i class="fas fa-trash"></i>
      </button>
    </div>`).join('');

  list.innerHTML = html;
}

// ─────────────────────────────────────────────
//  CATEGORY MODAL
// ─────────────────────────────────────────────
function openCategoryModal() {
  document.getElementById('catEditId').value = '';
  document.getElementById('catName').value   = '';
  selectedCatIcon  = '🏷️';
  selectedCatColor = '#10b981';
  currentCatType   = 'expense';
  document.querySelectorAll('#catModal .type-tab').forEach((b, i) => b.classList.toggle('active', i === 0));
  document.querySelectorAll('#catIconPicker .icon-opt').forEach((e, i) => e.classList.toggle('selected', i === 0));
  document.querySelectorAll('#catColorPicker .color-opt').forEach((e, i) => e.classList.toggle('selected', i === 0));
  setupIconPicker('catIconPicker', v => selectedCatIcon = v);
  setupColorPicker('catColorPicker', v => selectedCatColor = v);
  openModal('catModalOverlay', 'catModal');
}
function closeCategoryModal() { closeModal('catModalOverlay', 'catModal'); }
function setCatType(type, btn) {
  currentCatType = type;
  document.querySelectorAll('#catModal .type-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}
function saveCategory() {
  const name = document.getElementById('catName').value.trim();
  if (!name) { showToast('Informe o nome', 'error'); return; }
  DB.categories.add({ name, type: currentCatType, icon: selectedCatIcon, color: selectedCatColor });
  showToast('Categoria criada!', 'success');
  closeCategoryModal(); renderSettings(); renderCategoryPicker();
}
function deleteCategoryConfirm(id) {
  const cat = DB.categories.getById(id); if (!cat) return;
  if (cat.system) { showToast('Categorias padrão não podem ser excluídas', 'error'); return; }
  openConfirm('Excluir Categoria', `Excluir "${cat.name}"?`, () => {
    DB.categories.delete(id); showToast('Categoria excluída', 'info'); renderSettings();
  });
}

// ─────────────────────────────────────────────
//  ACCOUNT MODAL
// ─────────────────────────────────────────────
function openAccountModal() {
  document.getElementById('accEditId').value  = '';
  document.getElementById('accName').value    = '';
  document.getElementById('accBalance').value = '';
  document.getElementById('accType').value    = 'checking';
  document.getElementById('accModalTitle').textContent = 'Nova Conta';
  // Mostra saldo inicial para nova conta
  const balGroup = document.getElementById('accBalanceGroup');
  if (balGroup) balGroup.style.display = '';
  selectedAccColor = '#10b981';
  document.querySelectorAll('#accColorPicker .color-opt').forEach((e, i) => e.classList.toggle('selected', i === 0));
  setupColorPicker('accColorPicker', v => selectedAccColor = v);
  openModal('accModalOverlay', 'accModal');
}
function openEditAccount(id) {
  const acc = DB.accounts.getById(id);
  if (!acc) return;
  document.getElementById('accEditId').value  = id;
  document.getElementById('accName').value    = acc.name;
  document.getElementById('accBalance').value = formatInputValue(acc.balance);
  document.getElementById('accType').value    = acc.type;
  document.getElementById('accModalTitle').textContent = 'Editar Conta';
  // Oculta saldo inicial na edição
  const balGroup = document.getElementById('accBalanceGroup');
  if (balGroup) balGroup.style.display = 'none';
  selectedAccColor = acc.color || '#10b981';
  document.querySelectorAll('#accColorPicker .color-opt').forEach(e => {
    e.classList.toggle('selected', e.dataset.color === selectedAccColor);
  });
  setupColorPicker('accColorPicker', v => selectedAccColor = v);
  openModal('accModalOverlay', 'accModal');
}
function closeAccountModal() { closeModal('accModalOverlay', 'accModal'); }
function saveAccount() {
  const editId  = document.getElementById('accEditId').value;
  const name    = document.getElementById('accName').value.trim();
  const type    = document.getElementById('accType').value;
  const balance = parseFloat(document.getElementById('accBalance').value.replace(',', '.') || 0);
  if (!name) { showToast('Informe o nome da conta', 'error'); return; }

  if (editId) {
    DB.accounts.update(editId, { name, type, color: selectedAccColor });
    showToast('Conta atualizada!', 'success');
  } else {
    DB.accounts.add({ name, type, balance: balance || 0, color: selectedAccColor });
    showToast('Conta criada!', 'success');
  }
  closeAccountModal(); renderSettings(); renderDashboard();
}
function deleteAccountConfirm(id) {
  const acc = DB.accounts.getById(id); if (!acc) return;
  openConfirm('Excluir Conta', `Excluir a conta "${acc.name}"?`, () => {
    DB.accounts.delete(id); showToast('Conta excluída', 'info');
    renderSettings(); renderDashboard();
  });
}

// ─────────────────────────────────────────────
//  ICON / COLOR PICKER HELPERS
// ─────────────────────────────────────────────
function setupIconPicker(pickerId, onChange) {
  document.querySelectorAll(`#${pickerId} .icon-opt`).forEach(el => {
    el.addEventListener('click', () => {
      document.querySelectorAll(`#${pickerId} .icon-opt`).forEach(e => e.classList.remove('selected'));
      el.classList.add('selected');
      onChange(el.dataset.icon);
    });
  });
}
function setupColorPicker(pickerId, onChange) {
  document.querySelectorAll(`#${pickerId} .color-opt`).forEach(el => {
    el.addEventListener('click', () => {
      document.querySelectorAll(`#${pickerId} .color-opt`).forEach(e => e.classList.remove('selected'));
      el.classList.add('selected');
      onChange(el.dataset.color);
    });
  });
}

// ─────────────────────────────────────────────
//  EXPORT / IMPORT / CLEAR
// ─────────────────────────────────────────────
function exportData() {
  const data = DB.exportAll();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url;
  a.download = `financeapp_${Auth.currentUser()?.name || 'backup'}_${todayISO()}.json`;
  a.click(); URL.revokeObjectURL(url);
  showToast('Dados exportados!', 'success');
}
function importData(event) {
  const file = event.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      openConfirm('Importar Dados', 'Isso substituirá todos os dados atuais. Continuar?', () => {
        DB.importAll(data); showToast('Importado!', 'success'); location.reload();
      });
    } catch { showToast('Arquivo inválido', 'error'); }
  };
  reader.readAsText(file); event.target.value = '';
}
function confirmClearData() {
  openConfirm('Limpar Todos os Dados', 'Isso apagará TODOS os seus dados permanentemente. Tem certeza?', () => {
    DB.clearAll(); showToast('Dados apagados', 'info'); location.reload();
  });
}

// ─────────────────────────────────────────────
//  MODAL HELPERS
// ─────────────────────────────────────────────
function openModal(overlayId, sheetId) {
  document.getElementById(overlayId).classList.add('visible');
  setTimeout(() => document.getElementById(sheetId).classList.add('open'), 10);
  document.body.style.overflow = 'hidden';
}
function closeModal(overlayId, sheetId) {
  document.getElementById(sheetId).classList.remove('open');
  document.getElementById(overlayId).classList.remove('visible');
  document.body.style.overflow = '';
}

// ─────────────────────────────────────────────
//  CONFIRM DIALOG
// ─────────────────────────────────────────────
let confirmCallback = null;
function openConfirm(title, msg, onOk) {
  confirmCallback = onOk;
  document.getElementById('confirmTitle').textContent   = title;
  document.getElementById('confirmMessage').textContent = msg;
  document.getElementById('confirmOverlay').classList.add('visible');
  document.getElementById('confirmDialog').classList.add('visible');
  document.getElementById('confirmOkBtn').onclick = () => { closeConfirm(); confirmCallback?.(); };
}
function closeConfirm() {
  document.getElementById('confirmOverlay').classList.remove('visible');
  document.getElementById('confirmDialog').classList.remove('visible');
}

// ─────────────────────────────────────────────
//  TOAST
// ─────────────────────────────────────────────
let toastTimer = null;
function showToast(msg, type = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast ${type} show`;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
}

// ─────────────────────────────────────────────
//  UTILS
// ─────────────────────────────────────────────
function todayISO() { return new Date().toISOString().slice(0, 10); }

function formatDate(str) {
  if (!str || str === 'sem-data') return 'Sem data';
  const d = new Date(str + 'T00:00:00');
  return d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });
}
function formatDateShort(str) {
  if (!str) return '';
  return new Date(str + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}
function getCategoryName(id) { const c = DB.categories.getById(id); return c ? c.name : ''; }
function escHtml(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function formatAmountInput(input) {
  let v = input.value.replace(/[^\d,]/g, '');
  // Só permite uma vírgula
  const parts = v.split(',');
  if (parts.length > 2) v = parts[0] + ',' + parts.slice(1).join('');
  // Max 2 casas decimais
  if (parts[1] && parts[1].length > 2) v = parts[0] + ',' + parts[1].slice(0,2);
  input.value = v;
}
function formatInputValue(num) {
  if (!num && num !== 0) return '';
  return Number(num).toFixed(2).replace('.', ',');
}

// ─────────────────────────────────────────────
//  QUICK STATS UPDATE (called periodically)
// ─────────────────────────────────────────────
function refreshAllViews() {
  renderDashboard();
  updateNotifBadge();
}

// ─────────────────────────────────────────────
//  SWIPE GESTURE (close modals)
// ─────────────────────────────────────────────
(function setupSwipe() {
  let startY = 0;
  document.addEventListener('touchstart', e => { startY = e.touches[0].clientY; }, { passive: true });
  document.addEventListener('touchend', e => {
    const dy = e.changedTouches[0].clientY - startY;
    if (dy > 80) {
      // swipe down — fecha o sheet aberto
      const openSheet = document.querySelector('.bottom-sheet.open');
      if (openSheet) {
        const overlayId = openSheet.id.replace('Modal', 'ModalOverlay')
          .replace('profileModal', 'profileModalOverlay');
        if (openSheet.id === 'profileModal')   closeProfileModal();
        else if (openSheet.id === 'txModal')   closeTransactionModal();
        else if (openSheet.id === 'budgetModal') closeBudgetModal();
        else if (openSheet.id === 'goalModal')  closeGoalModal();
        else if (openSheet.id === 'catModal')   closeCategoryModal();
        else if (openSheet.id === 'accModal')   closeAccountModal();
        else if (openSheet.id === 'schedModal') closeScheduledModal();
        else if (openSheet.id === 'instModal')  closeInstallmentModal();
        else if (openSheet.id === 'parcelasModal') closeParcelasModal();
      }
    }
  }, { passive: true });
})();
