/**
 * FinanceApp — Database Multi-Usuário
 * Cada usuário tem seus próprios dados completamente isolados.
 * Estrutura no localStorage:
 *   financeapp_users   → array de { id, name, email, password, avatar, createdAt }
 *   financeapp_session → { userId }
 *   financeapp_data_{userId} → dados financeiros do usuário
 */

const Auth = (() => {
  const USERS_KEY   = 'financeapp_users';
  const SESSION_KEY = 'financeapp_session';

  function loadUsers() {
    try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; }
    catch { return []; }
  }
  function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  function uid() {
    return 'u_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  // ── Sessão ──
  function getSession() {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY)); }
    catch { return null; }
  }
  function setSession(userId) {
    localStorage.setItem(SESSION_KEY, JSON.stringify({ userId }));
  }
  function clearSession() {
    localStorage.removeItem(SESSION_KEY);
  }

  // ── Usuário atual ──
  function currentUser() {
    const session = getSession();
    if (!session) return null;
    return loadUsers().find(u => u.id === session.userId) || null;
  }

  // ── Cadastro ──
  function register({ name, email, password }) {
    const users = loadUsers();
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: 'Este e-mail já está cadastrado.' };
    }
    const user = {
      id: uid(),
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password, // em produção real deveria ser hash — aqui é client-only
      avatar: name.trim()[0].toUpperCase(),
      createdAt: Date.now()
    };
    users.push(user);
    saveUsers(users);
    setSession(user.id);
    return { ok: true, user };
  }

  // ── Login ──
  function login({ email, password }) {
    const users = loadUsers();
    const user  = users.find(
      u => u.email.toLowerCase() === email.trim().toLowerCase() && u.password === password
    );
    if (!user) return { ok: false, error: 'E-mail ou senha incorretos.' };
    setSession(user.id);
    return { ok: true, user };
  }

  // ── Logout ──
  function logout() { clearSession(); }

  // ── Atualizar perfil ──
  function updateProfile(changes) {
    const users = loadUsers();
    const idx = users.findIndex(u => u.id === currentUser()?.id);
    if (idx === -1) return;
    users[idx] = { ...users[idx], ...changes };
    if (changes.name) users[idx].avatar = changes.name.trim()[0].toUpperCase();
    saveUsers(users);
  }

  // ── Atualizar senha ──
  function changePassword(oldPwd, newPwd) {
    const user = currentUser();
    if (!user) return { ok: false, error: 'Não logado.' };
    if (user.password !== oldPwd) return { ok: false, error: 'Senha atual incorreta.' };
    const users = loadUsers();
    const idx = users.findIndex(u => u.id === user.id);
    users[idx].password = newPwd;
    saveUsers(users);
    return { ok: true };
  }

  // ── Lista de usuários (sem senhas) ──
  function listUsers() {
    return loadUsers().map(({ password, ...u }) => u);
  }

  return { register, login, logout, currentUser, updateProfile, changePassword, listUsers, getSession };
})();


// ══════════════════════════════════════════════
//  DB — dados por usuário
// ══════════════════════════════════════════════
const DB = (() => {
  const defaultCategories = () => [
    // Despesas
    { id: 'c1',  name: 'Alimentação',   type: 'expense', icon: '🍔', color: '#ef4444',  system: true },
    { id: 'c2',  name: 'Transporte',    type: 'expense', icon: '🚌', color: '#f59e0b',  system: true },
    { id: 'c3',  name: 'Saúde',         type: 'expense', icon: '💊', color: '#ec4899',  system: true },
    { id: 'c4',  name: 'Educação',      type: 'expense', icon: '📚', color: '#3b82f6',  system: true },
    { id: 'c5',  name: 'Lazer',         type: 'expense', icon: '🎬', color: '#8b5cf6',  system: true },
    { id: 'c6',  name: 'Moradia',       type: 'expense', icon: '🏠', color: '#0891b2',  system: true },
    { id: 'c7',  name: 'Vestuário',     type: 'expense', icon: '👕', color: '#d97706',  system: true },
    { id: 'c8',  name: 'Contas',        type: 'expense', icon: '📄', color: '#64748b',  system: true },
    { id: 'c9',  name: 'Mercado',       type: 'expense', icon: '🛒', color: '#16a34a',  system: true },
    { id: 'c10', name: 'Outros',        type: 'expense', icon: '📦', color: '#6b7280',  system: true },
    // Receitas
    { id: 'c11', name: 'Salário',       type: 'income',  icon: '💼', color: '#10b981',  system: true },
    { id: 'c12', name: 'Freelance',     type: 'income',  icon: '💻', color: '#06b6d4',  system: true },
    { id: 'c13', name: 'Investimentos', type: 'income',  icon: '📈', color: '#84cc16',  system: true },
    { id: 'c14', name: 'Presentes',     type: 'income',  icon: '🎁', color: '#f43f5e',  system: true },
    { id: 'c15', name: 'Outros',        type: 'income',  icon: '💰', color: '#a78bfa',  system: true },
  ];

  const defaultData = () => ({
    transactions: [],
    categories: defaultCategories(),
    accounts: [
      { id: 'a1', name: 'Carteira', type: 'wallet',   color: '#10b981', balance: 0 },
      { id: 'a2', name: 'Banco',    type: 'checking', color: '#3b82f6', balance: 0 },
      { id: 'a3', name: 'Poupança', type: 'savings',  color: '#f59e0b', balance: 0 },
    ],
    budgets:      [],
    goals:        [],
    scheduled:    [],   // lançamentos futuros / recorrentes
    installments: [],   // grupos de parcelas (cartão / parcelado)
    settings: { balanceVisible: true, currency: 'BRL', notifyDaysBefore: 3 }
  });

  function storageKey() {
    const user = Auth.currentUser();
    if (!user) throw new Error('Nenhum usuário logado');
    return `financeapp_data_${user.id}`;
  }

  function load() {
    try {
      const raw = localStorage.getItem(storageKey());
      if (!raw) return defaultData();
      const stored = JSON.parse(raw);
      const def = defaultData();
      return {
        ...def, ...stored,
        settings: { ...def.settings, ...(stored.settings || {}) },
        // garante que categorias padrão existem mesmo em contas antigas
        categories: mergeDefaultCategories(stored.categories || [])
      };
    } catch (e) {
      console.warn('DB load error', e);
      return defaultData();
    }
  }

  function mergeDefaultCategories(stored) {
    const defs = defaultCategories();
    const ids  = stored.map(c => c.id);
    const missing = defs.filter(d => !ids.includes(d.id));
    return [...stored, ...missing];
  }

  function save(data) {
    try { localStorage.setItem(storageKey(), JSON.stringify(data)); }
    catch (e) { console.warn('DB save error', e); }
  }

  let _data = null;

  function ensureLoaded() {
    if (!_data) _data = load();
  }

  function reload() { _data = load(); }

  function persist() { save(_data); }

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  // ── TRANSACTIONS ──
  const transactions = {
    getAll()  { ensureLoaded(); return [..._data.transactions]; },
    getById(id) { ensureLoaded(); return _data.transactions.find(t => t.id === id); },
    add(tx) {
      ensureLoaded();
      const record = { id: uid(), createdAt: Date.now(), ...tx };
      _data.transactions.unshift(record);
      accounts.updateBalance(tx.accountId, tx.type === 'income' ? tx.amount : -tx.amount);
      if (tx.type === 'transfer' && tx.accountToId)
        accounts.updateBalance(tx.accountToId, tx.amount);
      persist(); return record;
    },
    update(id, changes) {
      ensureLoaded();
      const idx = _data.transactions.findIndex(t => t.id === id);
      if (idx === -1) return null;
      const old = _data.transactions[idx];
      accounts.updateBalance(old.accountId, old.type === 'income' ? -old.amount : old.amount);
      if (old.type === 'transfer' && old.accountToId)
        accounts.updateBalance(old.accountToId, -old.amount);
      const updated = { ...old, ...changes };
      _data.transactions[idx] = updated;
      accounts.updateBalance(updated.accountId, updated.type === 'income' ? updated.amount : -updated.amount);
      if (updated.type === 'transfer' && updated.accountToId)
        accounts.updateBalance(updated.accountToId, updated.amount);
      persist(); return updated;
    },
    delete(id) {
      ensureLoaded();
      const tx = _data.transactions.find(t => t.id === id);
      if (!tx) return;
      accounts.updateBalance(tx.accountId, tx.type === 'income' ? -tx.amount : tx.amount);
      if (tx.type === 'transfer' && tx.accountToId)
        accounts.updateBalance(tx.accountToId, -tx.amount);
      _data.transactions = _data.transactions.filter(t => t.id !== id);
      persist();
    },
    getByMonth(year, month) {
      ensureLoaded();
      return _data.transactions.filter(t => {
        const d = new Date(t.date);
        return d.getFullYear() === year && d.getMonth() === month;
      });
    },
    getByYear(year) {
      ensureLoaded();
      return _data.transactions.filter(t => new Date(t.date).getFullYear() === year);
    }
  };

  // ── CATEGORIES ──
  const categories = {
    getAll()     { ensureLoaded(); return [..._data.categories]; },
    getById(id)  { ensureLoaded(); return _data.categories.find(c => c.id === id); },
    getByType(t) { ensureLoaded(); return _data.categories.filter(c => c.type === t); },
    add(cat) {
      ensureLoaded();
      const record = { id: uid(), system: false, ...cat };
      _data.categories.push(record);
      persist(); return record;
    },
    delete(id) {
      ensureLoaded();
      const cat = _data.categories.find(c => c.id === id);
      if (cat?.system) return; // não remove padrões
      _data.categories = _data.categories.filter(c => c.id !== id);
      persist();
    }
  };

  // ── ACCOUNTS ──
  const accounts = {
    getAll()    { ensureLoaded(); return [..._data.accounts]; },
    getById(id) { ensureLoaded(); return _data.accounts.find(a => a.id === id); },
    add(acc) {
      ensureLoaded();
      const record = { id: uid(), ...acc };
      _data.accounts.push(record);
      persist(); return record;
    },
    update(id, changes) {
      ensureLoaded();
      const idx = _data.accounts.findIndex(a => a.id === id);
      if (idx === -1) return;
      _data.accounts[idx] = { ..._data.accounts[idx], ...changes };
      persist();
    },
    delete(id) {
      ensureLoaded();
      _data.accounts = _data.accounts.filter(a => a.id !== id);
      persist();
    },
    updateBalance(id, delta) {
      ensureLoaded();
      const acc = _data.accounts.find(a => a.id === id);
      if (acc) { acc.balance = (acc.balance || 0) + delta; persist(); }
    },
    getTotalBalance() {
      ensureLoaded();
      return _data.accounts.reduce((s, a) => s + (a.balance || 0), 0);
    }
  };

  // ── BUDGETS ──
  const budgets = {
    getAll()    { ensureLoaded(); return [..._data.budgets]; },
    getById(id) { ensureLoaded(); return _data.budgets.find(b => b.id === id); },
    add(b) {
      ensureLoaded();
      const record = { id: uid(), ...b };
      _data.budgets.push(record);
      persist(); return record;
    },
    update(id, changes) {
      ensureLoaded();
      const idx = _data.budgets.findIndex(b => b.id === id);
      if (idx === -1) return;
      _data.budgets[idx] = { ..._data.budgets[idx], ...changes };
      persist();
    },
    delete(id) {
      ensureLoaded();
      _data.budgets = _data.budgets.filter(b => b.id !== id);
      persist();
    },
    getSpent(categoryId, year, month) {
      ensureLoaded();
      return _data.transactions
        .filter(t => t.type === 'expense' && t.categoryId === categoryId)
        .filter(t => {
          const d = new Date(t.date);
          return d.getFullYear() === year && d.getMonth() === month;
        })
        .reduce((s, t) => s + t.amount, 0);
    }
  };

  // ── GOALS ──
  const goals = {
    getAll()    { ensureLoaded(); return [..._data.goals]; },
    getById(id) { ensureLoaded(); return _data.goals.find(g => g.id === id); },
    add(g) {
      ensureLoaded();
      const record = { id: uid(), createdAt: Date.now(), ...g };
      _data.goals.push(record);
      persist(); return record;
    },
    update(id, changes) {
      ensureLoaded();
      const idx = _data.goals.findIndex(g => g.id === id);
      if (idx === -1) return;
      _data.goals[idx] = { ..._data.goals[idx], ...changes };
      persist();
    },
    delete(id) {
      ensureLoaded();
      _data.goals = _data.goals.filter(g => g.id !== id);
      persist();
    },
    contribute(id, amount) {
      ensureLoaded();
      const g = _data.goals.find(g => g.id === id);
      if (g) { g.current = (g.current || 0) + amount; persist(); }
    }
  };

  // ── SETTINGS ──
  const settings = {
    get()        { ensureLoaded(); return { ..._data.settings }; },
    set(changes) { ensureLoaded(); _data.settings = { ..._data.settings, ...changes }; persist(); }
  };

  // ── SCHEDULED TRANSACTIONS (lançamentos futuros / recorrentes) ──
  // Campos: id, type(income|expense), amount, description, categoryId, accountId,
  //         dueDate (YYYY-MM-DD), recurrence(none|daily|weekly|monthly|yearly),
  //         status(pending|paid|cancelled), notes, createdAt
  const scheduled = {
    getAll()     { ensureLoaded(); return [...(_data.scheduled || [])]; },
    getById(id)  { ensureLoaded(); return (_data.scheduled || []).find(s => s.id === id); },
    getPending() {
      ensureLoaded();
      return (_data.scheduled || []).filter(s => s.status === 'pending');
    },
    getOverdue() {
      ensureLoaded();
      const today = new Date().toISOString().slice(0,10);
      return (_data.scheduled || []).filter(s => s.status === 'pending' && s.dueDate < today);
    },
    getDueSoon(days = 3) {
      ensureLoaded();
      const today    = new Date();
      const limitDay = new Date(); limitDay.setDate(today.getDate() + days);
      const todayStr = today.toISOString().slice(0,10);
      const limitStr = limitDay.toISOString().slice(0,10);
      return (_data.scheduled || []).filter(s =>
        s.status === 'pending' && s.dueDate >= todayStr && s.dueDate <= limitStr
      );
    },
    add(s) {
      ensureLoaded();
      if (!_data.scheduled) _data.scheduled = [];
      const record = { id: uid(), createdAt: Date.now(), status: 'pending', ...s };
      _data.scheduled.push(record);
      persist(); return record;
    },
    update(id, changes) {
      ensureLoaded();
      if (!_data.scheduled) _data.scheduled = [];
      const idx = _data.scheduled.findIndex(s => s.id === id);
      if (idx === -1) return null;
      _data.scheduled[idx] = { ..._data.scheduled[idx], ...changes };
      persist(); return _data.scheduled[idx];
    },
    delete(id) {
      ensureLoaded();
      _data.scheduled = (_data.scheduled || []).filter(s => s.id !== id);
      persist();
    },
    // Marcar como pago → cria transação real e agenda próxima se recorrente
    markPaid(id) {
      ensureLoaded();
      const s = (_data.scheduled || []).find(s => s.id === id);
      if (!s || s.status !== 'pending') return null;

      // Cria transação efetiva
      const tx = transactions.add({
        type:        s.type,
        amount:      s.amount,
        description: s.description,
        categoryId:  s.categoryId,
        accountId:   s.accountId,
        date:        s.dueDate,
        notes:       s.notes || '',
        fromScheduled: id
      });

      // Marca lançamento como pago
      const idx = _data.scheduled.findIndex(x => x.id === id);
      _data.scheduled[idx].status = 'paid';
      _data.scheduled[idx].paidAt = Date.now();
      _data.scheduled[idx].txId   = tx.id;

      // Se recorrente, cria próximo lançamento
      if (s.recurrence && s.recurrence !== 'none') {
        const nextDate = calcNextDate(s.dueDate, s.recurrence);
        _data.scheduled.push({
          ...s,
          id:        uid(),
          createdAt: Date.now(),
          status:    'pending',
          dueDate:   nextDate,
          paidAt:    undefined,
          txId:      undefined
        });
      }
      persist(); return tx;
    }
  };

  function calcNextDate(dateStr, recurrence) {
    const d = new Date(dateStr + 'T12:00:00');
    switch (recurrence) {
      case 'daily':   d.setDate(d.getDate() + 1);     break;
      case 'weekly':  d.setDate(d.getDate() + 7);     break;
      case 'monthly': d.setMonth(d.getMonth() + 1);   break;
      case 'yearly':  d.setFullYear(d.getFullYear()+1); break;
    }
    return d.toISOString().slice(0,10);
  }

  // ── INSTALLMENTS (compras parceladas / cartão de crédito) ──
  // Campos: id, description, totalAmount, installmentCount, paidCount,
  //         firstDueDate, categoryId, accountId, notes, createdAt
  // Cada parcela vira um `scheduled` com installmentGroupId
  const installments = {
    getAll()    { ensureLoaded(); return [...(_data.installments || [])]; },
    getById(id) { ensureLoaded(); return (_data.installments || []).find(i => i.id === id); },
    add(inst) {
      ensureLoaded();
      if (!_data.installments) _data.installments = [];
      const groupId = uid();
      const record = {
        id: groupId, createdAt: Date.now(), paidCount: 0, ...inst
      };
      _data.installments.push(record);

      // Gera parcelas individuais no módulo scheduled
      const amtEach = +(inst.totalAmount / inst.installmentCount).toFixed(2);
      let firstDate  = new Date(inst.firstDueDate + 'T12:00:00');
      if (!_data.scheduled) _data.scheduled = [];

      for (let i = 0; i < inst.installmentCount; i++) {
        const dueDate = new Date(firstDate);
        dueDate.setMonth(firstDate.getMonth() + i);
        _data.scheduled.push({
          id:               uid(),
          createdAt:        Date.now(),
          status:           'pending',
          type:             'expense',
          amount:           amtEach,
          description:      `${inst.description} (${i+1}/${inst.installmentCount})`,
          categoryId:       inst.categoryId,
          accountId:        inst.accountId,
          dueDate:          dueDate.toISOString().slice(0,10),
          recurrence:       'none',
          notes:            inst.notes || '',
          installmentGroupId: groupId,
          installmentIndex:   i + 1,
          installmentTotal:   inst.installmentCount
        });
      }
      persist(); return record;
    },
    delete(id) {
      ensureLoaded();
      _data.installments = (_data.installments || []).filter(i => i.id !== id);
      // Remove parcelas pendentes associadas
      _data.scheduled = (_data.scheduled || []).filter(
        s => s.installmentGroupId !== id || s.status !== 'pending'
      );
      persist();
    },
    updatePaidCount(groupId) {
      ensureLoaded();
      const idx = (_data.installments || []).findIndex(i => i.id === groupId);
      if (idx === -1) return;
      const paid = (_data.scheduled || []).filter(
        s => s.installmentGroupId === groupId && s.status === 'paid'
      ).length;
      _data.installments[idx].paidCount = paid;
      persist();
    }
  };

  // ── EXPORT / IMPORT / CLEAR ──
  function exportAll() { ensureLoaded(); return JSON.parse(JSON.stringify(_data)); }
  function importAll(raw) {
    _data = {
      ...defaultData(), ...raw,
      categories:   mergeDefaultCategories(raw.categories || []),
      scheduled:    raw.scheduled    || [],
      installments: raw.installments || []
    };
    persist();
  }
  function clearAll() { _data = defaultData(); persist(); }

  // Chamado após login/logout para resetar cache
  function reset() { _data = null; }

  return {
    transactions, categories, accounts, budgets, goals,
    scheduled, installments,
    settings, exportAll, importAll, clearAll, reload, reset
  };
})();
