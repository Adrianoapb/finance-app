# 💰 FinanceApp — Controle Financeiro Pessoal

**App PWA completo de controle financeiro pessoal**, com visual mobile-first e instalação como APK Android via Chrome.

---

## 🚀 Funcionalidades Implementadas

### 📊 Dashboard
- Saldo total com toggle de visibilidade (privacidade)
- Resumo de receitas e despesas do mês
- Ações rápidas: Nova Receita, Nova Despesa, Transferência, Relatório
- Gráfico de barras dos últimos 7 dias
- Overview dos orçamentos ativos
- 8 transações mais recentes

### 💸 Transações
- Adicionar, editar e excluir transações
- Tipos: **Receita**, **Despesa** e **Transferência**
- Campos: valor, descrição, categoria, data, conta, notas
- Busca por texto em tempo real
- Filtros: tipo, categoria, mês
- Agrupamento por data
- Resumo de receitas, despesas e saldo filtrados

### 🏦 Contas Bancárias
- Múltiplas contas (Corrente, Poupança, Carteira, Investimentos, Cartão)
- Saldo automático ajustado pelas transações
- Cores personalizáveis

### 🏷️ Categorias
- 15 categorias padrão (10 despesas + 5 receitas)
- Criar categorias personalizadas com ícone, cor e tipo
- Excluir categorias

### 💡 Orçamentos
- Criar limites mensais por categoria
- Barra de progresso visual (verde/amarelo/vermelho)
- Alerta quando ultrapassa 80% / 100%
- Mini overview no dashboard

### 🎯 Metas Financeiras
- Nome, ícone, valor alvo, valor atual e data alvo
- Barra de progresso com percentual
- Botão "Adicionar Valor" para contribuições
- 12 ícones de metas disponíveis

### 📈 Relatórios
- 3 períodos: Mês, Trimestre, Ano
- Gráfico de barras: Receitas vs Despesas
- Gráfico de rosca: Despesas por categoria
- Gráfico de linha: Evolução do saldo
- Tabela detalhada por categoria com %

### ⚙️ Configurações
- Nome de usuário personalizado
- Exportar dados como JSON (backup)
- Importar dados de backup JSON
- Limpar todos os dados
- Instruções de instalação como app

### 📱 PWA (Progressive Web App)
- Service Worker para funcionamento offline
- Manifest.json para instalação como app
- Visual mobile com safe area insets
- Ícone de app 512x512

---

## 📁 Estrutura de Arquivos

```
/
├── index.html          # App completo (SPA)
├── manifest.json       # PWA manifest
├── sw.js               # Service Worker (cache offline)
├── css/
│   └── style.css       # Estilos mobile-first (dark theme)
├── js/
│   ├── db.js           # Banco de dados local (localStorage)
│   ├── charts.js       # Módulo de gráficos (Chart.js)
│   └── app.js          # Lógica principal da aplicação
└── images/
    └── icon-512.png    # Ícone do app
```

---

## 🗄️ Modelo de Dados (localStorage)

### `transactions`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | string | UUID único |
| type | enum | `income`, `expense`, `transfer` |
| amount | number | Valor em R$ |
| description | string | Descrição |
| categoryId | string | Referência à categoria |
| accountId | string | Conta de origem |
| accountToId | string | Conta destino (transfer) |
| date | string | ISO date `YYYY-MM-DD` |
| notes | string | Notas adicionais |
| createdAt | number | Timestamp |

### `categories`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | string | UUID |
| name | string | Nome |
| type | enum | `income` / `expense` |
| icon | string | Emoji |
| color | string | Cor hex |

### `accounts`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | string | UUID |
| name | string | Nome da conta |
| type | enum | `checking`, `savings`, `wallet`, etc |
| balance | number | Saldo atual |
| color | string | Cor hex |

### `budgets`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | string | UUID |
| categoryId | string | Categoria referenciada |
| limit | number | Limite mensal R$ |

### `goals`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | string | UUID |
| name | string | Nome da meta |
| icon | string | Emoji |
| target | number | Valor alvo R$ |
| current | number | Valor atual R$ |
| deadline | string | Data alvo |

---

## 📱 Como Instalar como APP (APK-like)

### Android (Chrome):
1. Abra o app no Chrome
2. Toque nos 3 pontinhos ⋮
3. Selecione "Adicionar à tela inicial"
4. Confirme a instalação

### iOS (Safari):
1. Abra no Safari
2. Toque em Compartilhar 
3. "Adicionar à Tela de Início"

---

## 🔗 URIs / Páginas

| Rota | Descrição |
|------|-----------|
| `/` | Dashboard principal |
| Seção `pageTransactions` | Lista de transações |
| Seção `pageBudgets` | Orçamentos mensais |
| Seção `pageGoals` | Metas financeiras |
| Seção `pageReports` | Relatórios e gráficos |
| Seção `pageSettings` | Configurações |

---

## 🛠️ Tecnologias

- **HTML5 / CSS3 / JavaScript (ES6+)** — sem frameworks
- **Chart.js** — gráficos
- **Font Awesome 6** — ícones
- **Google Fonts (Inter)** — tipografia
- **localStorage** — persistência de dados
- **Service Worker** — cache offline
- **PWA Manifest** — instalação como app nativo

---

## 🔮 Próximos Passos Sugeridos

- [ ] Sincronização com nuvem (Firebase/Supabase)
- [ ] Notificações push de alertas de orçamento
- [ ] Modo escuro/claro alternável
- [ ] Importação de extratos CSV/OFX
- [ ] Cartão de crédito com fatura mensal
- [ ] Múltiplos usuários / perfis
- [ ] Recorrência automática de transações
- [ ] Widget para tela inicial Android


## ✅ Ajustes feitos para empacotar como APK

- Corrigido `start_url` e `scope` do manifest para funcionar melhor em hospedagem estática.
- Criados ícones reais 192x192 e 512x512.
- Corrigido registro do Service Worker para caminho relativo.
- Corrigido cache offline para usar apenas arquivos existentes do projeto.
- Mantido fallback para abrir a aplicação mesmo sem internet.
